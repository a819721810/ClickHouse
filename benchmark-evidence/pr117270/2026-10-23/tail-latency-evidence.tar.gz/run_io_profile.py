from pathlib import Path
import json
import subprocess
import uuid
from run_matrix import DOCKER, IMAGE, check_container_isolation
ROOT=Path(__file__).resolve().parent
run=ROOT/'build'/('io_profile_'+uuid.uuid4().hex[:10]);run.mkdir()
manifest={'status':'running','cases':[],'order':['A','B','B','A'],'modes':['io_profile'],'rounds':2048,'readers':4,'scope':'Separate diagnostic; adds timing instrumentation; does not replace primary benchmark samples.'}
audit=run/'container_isolation.jsonl'
try:
    for mode in manifest['modes']:
        for block,variant in enumerate(manifest['order']):
            key=f'{mode}_{block}_{variant}';output=run/key;output.mkdir()
            name='pr117270-io-profile-'+run.name[-10:]+'-'+key.lower()
            command=[DOCKER,'run','--rm','--name',name,'--platform','linux/arm64','--network','none','--hostname','pr117270-bench','--add-host','pr117270-bench:127.0.0.1','--memory','6g','--memory-swap','6g','--cpus','4','--cpuset-cpus','0-3','-e','DIAGNOSTIC_MODE='+mode,'--mount',f'type=bind,src={ROOT/"bin"},dst=/inputs,readonly','--mount',f'type=bind,src={ROOT},dst=/bench,readonly','--mount',f'type=bind,src={ROOT},dst=/scripts,readonly','--mount',f'type=bind,src={output},dst=/out','--entrypoint','python3',IMAGE,'/scripts/stress_io_profile.py','--variant',variant,'--users','512','--combinations','32','--rounds','2048','--readers','4','--block',str(block)]
            (output/'command.json').write_text(json.dumps(command,indent=2)+'\n')
            check_container_isolation(name,audit);print('DIAGNOSTIC_START',key,flush=True)
            with (output/'test.log').open('w') as log:
                proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
                try:
                    while True:
                        try:code=proc.wait(timeout=5);break
                        except subprocess.TimeoutExpired:check_container_isolation(name,audit)
                    assert code==0,(key,code)
                    check_container_isolation(name,audit)
                except BaseException:
                    subprocess.run([DOCKER,'stop','--time','5',name],stdout=log,stderr=subprocess.STDOUT);proc.wait();raise
            result=json.loads((output/'result.json').read_text());assert result['status']=='passed'
            manifest['cases'].append({'path':str(output.relative_to(ROOT)),**result})
            (run/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
            print('DIAGNOSTIC_CASE_PASS',key,result['reader_summary'],result['writer_summary'],flush=True)
    manifest['status']='passed';print('DIAGNOSTIC_PASS',run,flush=True)
except BaseException as error:
    manifest.update(status='failed',error=repr(error));raise
finally:
    (run/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (ROOT/'latest_io_profile.json').write_text(json.dumps({'path':str(run),'status':manifest['status']},indent=2)+'\n')
