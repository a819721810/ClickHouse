import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time
import uuid

spec=importlib.util.spec_from_file_location('bench','/bench/run_case.py')
bench=importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)

class Fixture:
    def __init__(self, variant='B'):
        self.variant=variant
        self.clients=[]
        self.out=Path('/out')
        self.work=Path('/work')
        self.identity='followup_'+uuid.uuid4().hex
        self.binary='/inputs/clickhouse-B' if variant=='B' else '/inputs/clickhouse-A-runtime'
    def client(self,user='default',session=None,database='default'):
        client=bench.Client(user,session,database)
        self.clients.append(client)
        return client
    def __enter__(self):
        self.work.mkdir()
        (self.work/'config.xml').write_text(bench.config(self.identity))
        self.log=(self.out/'server_stdout.log').open('w')
        command=[self.binary,'server','--config-file=/work/config.xml']
        if os.environ.get('DIAGNOSTIC_MODE') in ('split_cpus','quiet_split'):
            command=['taskset','--cpu-list','0-3']+command
        environment=dict(os.environ,CLICKHOUSE_WATCHDOG_ENABLE='0')
        if os.environ.get('DIAGNOSTIC_MODE')=='mutex_trace':
            command=['/lib/ld-linux-aarch64.so.1','--preload','/scripts/build/libcache_mutex_trace.so']+command
        if os.environ.get('DIAGNOSTIC_MODE')=='storage_trace':
            command=['/lib/ld-linux-aarch64.so.1','--preload',f'/scripts/build/libstorage_mutex_trace_{self.variant}.so']+command
        self.proc=subprocess.Popen(command,cwd=self.work,env=environment,stdout=self.log,stderr=subprocess.STDOUT)
        deadline=time.monotonic()+120
        while True:
            if self.proc.poll() is not None: raise RuntimeError('Server exited at startup')
            try:
                self.admin=self.client()
                assert self.admin.query("SELECT getMacro('benchmark_isolation')")[0]==self.identity
                break
            except (ConnectionError,OSError):
                self.admin.close()
                if time.monotonic()>deadline: raise RuntimeError('Server startup timeout')
                time.sleep(0.1)
        self.options={r['name']:r['value'] for r in self.admin.rows('SELECT * FROM system.build_options')}
        expected='3319c0bf1944237c0ed87eac0fb0affc61a7d609' if self.variant=='B' else 'dd7889a115c63e16f3bcbc9f843e4633fb2fe1e0'
        assert self.options['GIT_HASH']==expected
        return self
    def events(self,query_id):
        self.admin.query('SYSTEM FLUSH LOGS')
        rows=self.admin.rows("SELECT query_id,toString(type) AS type,query_duration_ms,ProfileEvents['EffectiveAccessRightsCalculations'] AS calculations,ProfileEvents['EffectiveAccessRightsCacheHits'] AS cache_hits FROM system.query_log WHERE query_id='"+query_id+"' AND type!='QueryStart'")
        assert len(rows)==1 and rows[0]['type']=='QueryFinish',rows
        return rows[0]
    def __exit__(self,*args):
        for c in self.clients:c.close()
        if self.proc.poll() is None:
            self.proc.terminate()
            self.proc.wait(timeout=30)
        self.log.close()
