from pathlib import Path
import mmap,struct,json
root=Path(__file__).resolve().parent
result={}
for variant,binary in [('A','clickhouse-A-runtime'),('B','clickhouse-B')]:
 with (root/'bin'/binary).open('rb') as file:
  elf=mmap.mmap(file.fileno(),0,access=mmap.ACCESS_READ)
  assert elf[:6]==b'\x7fELF\x02\x01'
  etype=struct.unpack_from('<H',elf,16)[0];assert etype==2,etype
  shoff=struct.unpack_from('<Q',elf,40)[0]
  entsize,count=struct.unpack_from('<HH',elf,58)
  sections=[struct.unpack_from('<IIQQQQIIQQ',elf,shoff+i*entsize) for i in range(count)]
  symbols=[]
  for section in sections:
   if section[1]!=2:continue
   strings=sections[section[6]]
   for offset in range(section[4],section[4]+section[5],section[9]):
    name,info,other,index,value,size=struct.unpack_from('<IBBHQQ',elf,offset)
    if not value or not size:continue
    start=strings[4]+name;end=elf.find(b'\0',start)
    symbol=elf[start:end]
    if (b'EffectiveAccessRightsCache' in symbol and (b'4find' in symbol or b'5store' in symbol or b'sweepExpiredEntries' in symbol)) or (b'DiskAccessStorage' in symbol and any(x in symbol for x in (b'findImpl',b'readImpl',b'updateImpl'))) or symbol in (b'pthread_mutex_lock',b'_ZNSt3__15mutex4lockEv'):
     symbols.append({'name':symbol.decode(),'address':value,'size':size})
  result[variant]=symbols
(root/'storage_symbol_ranges.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
