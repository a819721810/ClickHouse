from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
s=json.loads((ROOT/'investigation-summary.json').read_text())
assert s['status']=='passed'
rep=s['unprofiled_repeat_and_serial']['repeat']
serial=s['unprofiled_repeat_and_serial']['serial']
slow=max(s['cache_lock_diagnostic'],key=lambda row:row['writer_p99_ms'])
lines=['# 512 用户缓存压力尾延迟调查，2026-10-23','',
'## Performance verdict','',
'结论：`unstable test` / `local-only evidence`。调查确认了短基准中的公共请求、线程协调和访问存储等待，且在重现的慢块中，新缓存临界区不是主要耗时。不能将原先单组约 2 倍的 P99 直接认定为稳定的缓存实现回退。原始坏块没有保留逐请求锁、调用栈和宿主机轨迹，无法唯一还原当时的触发事件。','',
'这一结论也不等于零回退：新的原始脚本重复实验中，B 的 P99 仍较 A 高约 12–15%，中位数与 P95 也有差异，下面完整保留。此前零复用角色组合的 5–7% 开销结论没有被本调查推翻。','',
'## Evidence checked','',
'- A 为 `dd7889a115c63e16f3bcbc9f843e4633fb2fe1e0`，B 为 `3319c0bf1944237c0ed87eac0fb0affc61a7d609`。每轮运行时 `GIT_HASH` 均严格核对；当前缓存两份 C++ 源文件与 B 提交逐字相同。未修改生产 C++，未重编服务器，未推送或部署。',
'- 场景是预装 512 个用户、每用户 32 个角色组合；实际计时并发是四个 `SELECT 1` reader 加一个权限更新 writer。512 是缓存规模，不是 512 个并发请求。这比“512 用户并发”这一简称准确。',
'- 原始资源为同容器四个 vCPU、`cpuset 0-3`、6 GiB，服务器和 Python 发生器共用资源。CPU 分离探索组增加到六个 vCPU，因此不是纯亲和性单变量对照；该组仅用于诊断。',
'- 原始压力每块只有 2048 个同步轮次，耗时约一至数秒。原始脚本本轮重复四组 A/B/B/A，共八块/版本；脚本和原始 `Client` 与先前基准逐字一致，没有 HTTP 分段计时插桩。',
f"- 共 {sum(p['cases'] for p in s['phases'].values())} 个接受 case、{sum(p['isolation_audits'] for p in s['phases'].values())} 次干净隔离审计。各阶段用途和设置不同，绝不混池为一组 A/B。失败、中断或没有实际锁记录的实验不计入相应结论。",
'- 采集资源计数的诊断组没有出现 CPU quota 限流。宿主机并非独占；重复测试结束附近的快照显示其他活跃负载和较多压缩内存，但这不是最初坏块的历史证据，不能据此指定某个应用或内存压缩为根因。','',
'## Changed metrics','',
'### 原始脚本的新重复实验','',
'| 请求 | 版本 | Median / P95 / P99，ms | 各块 P99 范围，ms |',
'|---|---|---:|---:|']
for kind in ('reader','writer'):
 for v in ('A','B'):
  r=rep[v][kind];x=r['pooled'];b=r['block_p99_ms']
  lines.append(f"| {kind} | {v} | {x['median']:.3f} / {x['p95']:.3f} / {x['p99']:.3f} | {min(b):.3f}–{max(b):.3f} |")
lines+=['', '两版本都出现过约 1.8–2.1 ms 的 reader P99；跨块波动很明显。新的 pooled B/A reader P99 为 '+f"{rep['B']['reader']['pooled']['p99']/rep['A']['reader']['pooled']['p99']:.3f} 倍，writer 为 {rep['B']['writer']['pooled']['p99']/rep['A']['writer']['pooled']['p99']:.3f} 倍。"+'这比原先两块/版本的约 2 倍更能说明当前重复性，但不证明剩余差异全是噪声。原始不利结果保留在历史目录，没有删除或用快样本替换。','',
'### 新缓存锁的直接测量','',
f"四个独立 B 轮次均有实际锁记录、零溢出；每轮计时窗口恰好 10,240 次 `find` 和 2048 次 `store`。其中慢块 reader/writer P99 为 {slow['reader_p99_ms']:.3f}/{slow['writer_p99_ms']:.3f} ms。",
f"该块 {slow['slow_writer_count']} 个超过 1 ms 的 writer 中，每个请求自身 `find` 加 `store` 的锁等待与持有时间合计中位数为 **{slow['slow_cache_us']['median']:.3f} µs**，占请求墙时中位数 **{slow['slow_cache_fraction_percent']['median']:.2f}%**。匹配依据是同一轮 writer 的 `store` TID，关联其 `find`，并验证两个完整锁区间都位于该 writer 请求时间窗内。",
f"最慢 writer 为 **{slow['slowest_writer']['wall_ms']:.3f} ms**，缓存锁合计只有 **{slow['slowest_writer']['cache_wait_hold_us']:.3f} µs**；首次进入缓存前约 **{slow['slowest_writer']['before_first_cache_us']/1000:.3f} ms**。因此这批重现的毫秒级等待不能主要归于新缓存临界区。",
'计时器会扰动运行，这些轮次只用于归因，不作为 A/B 性能倍率；也不能推广为所有用户规模、并发和角色组合都没有缓存锁风险。','',
'### 同一轮内的两项因果对照','',
'每两个轮次交替开关；每种状态都有相同数量的 `GRANT` 和 `REVOKE`，实际发生器、服务器和时间段共享。','',
'| 对照 | 版本/请求 | 状态 0 Median / P99，ms | 状态 1 Median / P99，ms |',
'|---|---|---:|---:|']
for name,description,kind in [('interleaved','并行格式化：0 关闭，1 开启','reader'),('coalesced','HTTP 发送：0 标准，1 合并头体','writer')]:
 for v in ('A','B'):
  x=s['within_run_controls'][name]['aggregate'][v][kind]
  lines.append(f"| {description} | {v} / {kind} | {x['0']['median']:.3f} / {x['0']['p99']:.3f} | {x['1']['median']:.3f} / {x['1']['p99']:.3f} |")
lines+=['',
'- 并行格式化关闭后 reader 中位数约降低 20%，P99 只降低约 4%，writer P99 没有相应改善。它是确定的公共开销，不能单独解释原先 2 倍。设置通过四个 probe 的 `getSetting` 实际回读确认。',
'- 合并 HTTP 请求头和请求体的发送，改善了 A、B 的 reader/writer 尾部。每个计时请求均核对 `HTTPConnection.send` 调用次数为标准方式两次、合并方式一次；没有测量 TCP 包数或内核 syscall 次数，不能混称。说明基准确实包含客户端供给/HTTP 交互开销。',
'- 另一个整轮关闭格式化的八块实验，两版本 P99 接近约 0.7–0.8 ms，但仍有约 10–14 ms 的极端单次值。整轮对照发生在另一时段，不用于独立证明最初尾部由格式化触发。','',
'## Why this verdict','',
'### 已确认的公共等待路径','',
'1. `FormatFactory::getOutputFormatParallelIfPossible` 会对这些单行结果启用 `ParallelFormattingOutputFormat`。CPU/Real 栈显示 collector、`finalizeImpl`、线程池提交与销毁中的条件等待。包含辅助线程的 Real 样本中该类频繁出现，但这不能解释成单请求相同比例的墙时。',
'2. `executeQuery` 读取请求体时，经 `ReadBufferFromPocoSocketBase` 到 `poll` 的 Real 等待在四轮都存在。头体合并发送的同轮对照证实客户端交互确实影响延迟；不能进一步把所有等待归因于物理网络或 GIL。',
'3. `DiskAccessStorage::updateImpl` 持其互斥锁完成临时文件写入、关闭和 `rename`；`findImpl`、`readImpl`、`exists` 等读路径也使用该锁。一次直接锁记录中 writer 持锁 2046 µs，两个其他线程同时等待约 2058/2036 µs，该轮读写请求都在约 2.3–2.5 ms，证明了跨用户放大机制。',
'4. 该长持锁请求的 `DiskWriteElapsedMicroseconds` 只有 3 µs；`rename`、文件元数据操作及持锁期间调度仍可能影响它，不能把完整 2 ms 都说成 `write` 或 `fsync`。原代码没有在该路径显式调用 `fsync`。',
'5. 即使权限目录确实挂载 tmpfs，没有新缓存的 A 仍出现 reader/writer P99 2.007/1.512 ms。因此新缓存及 overlay 权限文件写入都不是这类尾部的必要条件。',
'6. 另一个 GC 观测慢块有 424 个超过 1 ms 的请求，仅 2 个与 GC 区间重叠；GC 不能解释其大部分尾部。多进程发生器仍出现过慢块，因此也不能单独归因于单 Python 进程的 GIL。','',
'### 尚不能证明的部分','',
'最初坏块的 123 个超过 1 ms 的 writer，有 118 个在 `query_log` 中仍记录为 0 ms；0 是毫秒量化值，不是零执行时间。113 个同轮伴随慢 reader，主要聚集在约 0.6–1.3 秒窗口，支持公共请求或调度慢窗口。但当时未保留细粒度记录，HTTP/查询前处理、访问存储阻塞与虚拟机/宿主机调度无法唯一拆分。新的重现能排除其中某些解释，不能冒充对历史每个慢请求的直接跟踪。','',
'CPU/Real 诊断使用 1 ms 周期，共 578 CPU、22,731 Real 样本；CPU 很稀疏，约半数 Real 叶端未解析，但上层等待调用链可读。包含辅助线程和多线程采样，不能直接累加为单请求耗时。少量 merge `ABORTED` 出现在输出证据之后的停机清理阶段，没有失败请求；这些日志保留。','',
'## Recommended next step','',
'- 将原先约 2 倍描述为不稳定的本地短测观察，保留完整原始样本；不要据此要求再次重写或分片 `EffectiveAccessRightsCache`。新重复中约 12–15% 的 P99 差异仍保留为未完全解释的观察。',
'- 后续分开衡量权限计算、访问存储持久化和端到端请求。端到端测量使用更长窗口、多轮交错；对单行控制查询明确输出格式化策略和 HTTP 发送方式，区分预装用户数与实际请求并发。不要为了通过基准更改生产持久化或权限同步语义。',
'- 现有大权限树、同角色多上下文的加速证据没有被本次调查否定；这里不外推生产 `ON CLUSTER`，也没有新增 CI 通过结论。','',
'原始数据索引：`investigation-summary.json`、`per-case-results.csv`、各 `latest_*.json` 指向的 case 目录及完整 collapsed/锁二进制。缓存锁格式为 16 字节计数头后 `<QQQQII>`，存储锁格式为同一计数头后 `<QQQQQII>`，单位为 ns。两者固定地址范围只适用于记录的精确 ELF；换二进制必须重新生成符号范围。','',
'复现依赖已存在的精确 A/B 二进制和固定 builder 镜像，证据包不包含数 GiB 的服务器文件。早期探索脚本逐步加入 GC、配置回读等诊断；原始重复及同轮控制的实际脚本都在包内。部分早期 manifest 的 scope 沿用“增加计时插桩”模板，但原始重复/serial 实际没有 `MeasuredClient` 分段计时，按脚本和日志判断。']
(ROOT/'tail-latency-investigation.md').write_text('\n'.join(lines)+'\n')
print('INVESTIGATION_REPORT_PASS',len(lines),'lines')
