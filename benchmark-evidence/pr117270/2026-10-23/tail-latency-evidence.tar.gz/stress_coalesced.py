from pathlib import Path
import threading
import json
import server_support
send_state=threading.local()
OriginalConnection=server_support.bench.http.client.HTTPConnection
class Connection(OriginalConnection):
    def send(self,data):
        self.request_send_calls+=1
        return super().send(data)
    def _send_output(self,message_body=None,encode_chunked=False):
        self.request_send_calls=0
        if not getattr(send_state,'coalesced',0):
            return super()._send_output(message_body,encode_chunked=encode_chunked)
        assert not encode_chunked and isinstance(message_body,bytes)
        self._buffer.extend((b'',b''))
        header=b'\r\n'.join(self._buffer)
        self._buffer.clear()
        self.send(header+message_body)
server_support.bench.http.client.HTTPConnection=Connection
script=Path('/scripts/stress_server.py').read_text()
script=script.replace('                    barrier.wait(timeout=60)', '                    send_state.coalesced=(iteration//2+args.block)%2\n                    barrier.wait(timeout=60)')
marker='                    finish=time.perf_counter_ns()'
insert='''                    finish=time.perf_counter_ns()
                    sends=(writer if index==args.readers else probes[index]).connection.request_send_calls
                    assert sends==(1 if send_state.coalesced else 2),sends
'''
assert script.count(marker)==1
script=script.replace(marker,insert)
script=script.replace('wall_ms=(finish-begin)/1e6)', 'wall_ms=(finish-begin)/1e6, coalesced=send_state.coalesced, send_calls=sends)')
exec(compile(script,'interleaved_http_send_control','exec'))
