# Reproduction inputs, 2026-10-23

This is a checked local evidence bundle, not a standalone container image. It does not contain the multi-gigabyte server binaries or a complete ClickHouse checkout. Use the exact A/B binaries identified in `binary_receipt.json` and the pinned builder image in `inputs.json`; B is the locally built `3319c0bf194` binary. The current checkout has a later test-only commit; production cache sources are byte-identical.

Place the binaries in `bin/clickhouse-A-runtime` and `bin/clickhouse-B`. Run scripts from this directory, with unrelated Docker containers paused and no builds or other benchmark containers active. Each script creates fresh case directories and updates a `latest_*.json` pointer; it does not remove old raw data. Copy the evidence directory before rerunning if you need to keep its original pointers unchanged. Raw pointer JSON contains this machine's absolute paths; relocating the archive requires updating those paths.

```bash
python3 run_repeat.py > build/test_repeat_new.log 2>&1
python3 run_serial.py > build/test_serial_new.log 2>&1
python3 run_interleaved.py > build/test_interleaved_new.log 2>&1
python3 run_coalesced.py > build/test_coalesced_new.log 2>&1
```

The first command repeats the original load generator without segmented timing. The serial formatting control changes only the default formatting setting and reads it back before measuring. The two interleaved controls alternate state every two rounds so both `GRANT` and `REVOKE` are balanced in both states. The HTTP control counts calls to `HTTPConnection.send`, not packets or system calls.

Exploratory `run_diagnostic.py`, `run_controls.py`, `run_mutex_trace.py`, `run_storage.py` and `run_io_profile.py` have different diagnostic purposes and must not be pooled as one timing experiment. Some early manifest scope strings retain a generic instrumentation description; actual script paths and hashes identify whether a phase uses segmented timing. Earlier exploratory wrappers evolved to add GC/configuration readback; their raw observations remain unchanged.

`run_io_profile.py` requests a one-millisecond CPU/Real sampling period only for the measured query IDs. Its timings are not performance ratios, and helper-thread Real samples are not fractions of a single request's elapsed time.

The lock tracers are standalone diagnostic shared libraries; the ClickHouse source/binary is not patched. They use the exact ELF symbol ranges, the imported `__pthread_mutex_lock@GLIBC_2.17` backend, and frame-pointer callers to identify locks. ClickHouse clears `LD_PRELOAD`, so the successful runs use the loader's explicit `--preload` option. Failed or ineffective early attempts are preserved in `failed-experiments.json`; the GC-only phase explicitly records that mutex instrumentation was inactive.

`cache_mutex.bin` has two little-endian uint64 counts (record count, overflow count), followed by `<QQQQII>` records: begin ns, wait ns, hold ns, mutex address, TID, kind (1=find, 2=store). `storage_mutex.bin` adds the callsite before TID, hence `<QQQQQII>`; kinds 3/4/5 are `DiskAccessStorage` find/read/update. Symbolized callsites are in `build/lock_callsites_symbolized.log`. Ranges are valid only for the exact recorded ELF; another build requires regenerating them. Library source and the small compiled diagnostic libraries are included, but server binaries are excluded.

All accepted raw directories are indexed by `investigation-summary.json`. The historical original pressure matrix is preserved separately in the archive for retrospective comparison; it is not pooled with newer measurements. Private host process-name snapshots are deliberately excluded from the archive. No production service or PR is changed by packaging this evidence.
