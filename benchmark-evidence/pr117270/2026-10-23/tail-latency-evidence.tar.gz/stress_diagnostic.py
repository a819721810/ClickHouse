import os
import sys
import json
import time
import resource
import gc
import multiprocessing
import threading
from pathlib import Path
import urllib.parse
import server_support

mode = os.environ['DIAGNOSTIC_MODE']
assert mode in ('threads', 'short_gil', 'processes', 'quiet_logs', 'split_cpus', 'quiet_split', 'mutex_trace', 'storage_trace', 'access_tmpfs')
if mode == 'short_gil':
    sys.setswitchinterval(0.0001)

class MeasuredClient(server_support.bench.Client):
    def query(self, sql, query_id=None, session_check=False):
        begin = time.perf_counter_ns()
        cpu_begin = time.thread_time_ns()
        parameters = {'database': self.database}
        if query_id:
            parameters['query_id'] = query_id
        if self.session:
            parameters.update(session_id=self.session, session_timeout=3600)
            if session_check:
                parameters['session_check'] = 1
        url = '/?' + urllib.parse.urlencode(parameters)
        prepared = time.perf_counter_ns()
        self.connection.request('POST', url, body=sql.encode(), headers={
            'X-ClickHouse-User': self.user, 'Content-Type': 'text/plain; charset=utf-8'})
        sent = time.perf_counter_ns()
        response = self.connection.getresponse()
        headers = time.perf_counter_ns()
        body = response.read().decode()
        finished = time.perf_counter_ns()
        cpu_finish = time.thread_time_ns()
        summary = response.getheader('X-ClickHouse-Summary')
        self.last_metrics = {
            'prepare_us': (prepared-begin)/1000,
            'send_us': (sent-prepared)/1000,
            'headers_us': (headers-sent)/1000,
            'body_us': (finished-headers)/1000,
            'thread_cpu_us': (cpu_finish-cpu_begin)/1000,
            'http_elapsed_ns': int(json.loads(summary)['elapsed_ns']) if summary else None,
        }
        if response.status != 200:
            raise RuntimeError(f'HTTP {response.status}: {body[:2000]}')
        return body.strip(), (finished-prepared)/1e9

server_support.bench.Client = MeasuredClient
original_config=server_support.bench.config
def diagnostic_config(identity):
    config=original_config(identity)
    if mode in ('quiet_logs','quiet_split'):
        config=config.replace('<flush_interval_milliseconds>1000</flush_interval_milliseconds>', '<flush_interval_milliseconds>600000</flush_interval_milliseconds>')
    if mode=='access_tmpfs':
        config=config.replace('<local_directory><path>/work/access/</path>', '<local_directory><path>/access_ram/</path>')
    return config
server_support.bench.config=diagnostic_config
if mode in ('split_cpus','quiet_split'):
    os.sched_setaffinity(0,{4,5})

def snapshot():
    result = {'monotonic_ns':time.monotonic_ns()}
    for name in ('cpu.stat','cpu.pressure','cpu.max','memory.events','memory.current'):
        result[name] = Path('/sys/fs/cgroup',name).read_text()
    usage = resource.getrusage(resource.RUSAGE_SELF)
    result['client_process_rusage'] = {name:getattr(usage,name) for name in ('ru_utime','ru_stime','ru_nvcsw','ru_nivcsw','ru_maxrss')}
    return result

# Keep the production fixture, SQL, four readers and writer unchanged. Add only
# measurements, and replace the load-generator concurrency model in one control.
script = Path('/scripts/stress_server.py').read_text()
script = script.replace("        started=time.perf_counter_ns()", "        gc_records=[]\n        def gc_callback(phase,info):\n            gc_records.append({'phase':phase,'generation':info['generation'],'time_ns':time.perf_counter_ns(),'pid':os.getpid(),'thread':threading.get_native_id()})\n        gc.callbacks.append(gc_callback)\n        (out/'effective_config.xml').write_text((f.work/'config.xml').read_text())\n        (out/'mountinfo.txt').write_text(Path('/proc/self/mountinfo').read_text())\n        result['actual_server_affinity']=sorted(os.sched_getaffinity(f.proc.pid))\n        result['actual_client_affinity']=sorted(os.sched_getaffinity(0))\n        diagnostic_before=snapshot()\n        started=time.perf_counter_ns()")
script = script.replace("        barrier=threading.Barrier(args.readers+1)", "        barrier=(multiprocessing.get_context('fork').Barrier(args.readers+1) if mode=='processes' else threading.Barrier(args.readers+1))")
script = script.replace("                    finish=time.perf_counter_ns()", "                    finish=time.perf_counter_ns()\n                    metrics=(writer if index==args.readers else probes[index]).last_metrics")
script = script.replace("wall_ms=(finish-begin)/1e6)", "wall_ms=(finish-begin)/1e6, diagnostic=metrics)")
old = '''        with ThreadPoolExecutor(max_workers=args.readers+1) as pool:
            futures=[pool.submit(run_worker,index) for index in range(args.readers+1)]
            groups=[future.result() for future in futures]
'''
new = '''        if mode=='processes':
            def child(index):
                samples=run_worker(index)
                (out/f'worker_{index}.json').write_text(json.dumps(samples))
            processes=[multiprocessing.get_context('fork').Process(target=child,args=(index,)) for index in range(args.readers+1)]
            for proc in processes:proc.start()
            for proc in processes:
                proc.join(timeout=120)
                assert proc.exitcode==0,(proc.pid,proc.exitcode)
            groups=[json.loads((out/f'worker_{index}.json').read_text()) for index in range(args.readers+1)]
        else:
            with ThreadPoolExecutor(max_workers=args.readers+1) as pool:
                futures=[pool.submit(run_worker,index) for index in range(args.readers+1)]
                groups=[future.result() for future in futures]
        diagnostic_after=snapshot()
        gc.callbacks.remove(gc_callback)
        result['gc_records']=gc_records
        result['pressure_started_ns']=started
        result['pressure_finished_ns']=time.perf_counter_ns()
        result['diagnostic_mode']=mode
        result['switch_interval_seconds']=sys.getswitchinterval()
        result['resource_before']=diagnostic_before
        result['resource_after']=diagnostic_after
'''
assert script.count(old)==1
script = script.replace(old,new)
script = script.replace("ProfileEvents['EffectiveAccessRightsCalculations'] AS calculations,", "ProfileEvents['DiskWriteElapsedMicroseconds'] AS disk_write_us,ProfileEvents['FileSyncElapsedMicroseconds'] AS file_sync_us,ProfileEvents['RealTimeMicroseconds'] AS real_us,ProfileEvents['UserTimeMicroseconds'] AS user_cpu_us,ProfileEvents['SystemTimeMicroseconds'] AS system_cpu_us,ProfileEvents['OSCPUWaitMicroseconds'] AS cpu_wait_us,ProfileEvents['EffectiveAccessRightsCalculations'] AS calculations,")
exec(compile(script, 'instrumented_pressure_diagnostic', 'exec'))
