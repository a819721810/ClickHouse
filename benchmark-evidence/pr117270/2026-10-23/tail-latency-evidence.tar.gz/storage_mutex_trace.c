#define _GNU_SOURCE
#include <pthread.h>
#include <dlfcn.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stddef.h>
#include <time.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>

/* Diagnostic for the fixed-address optimized ELF only. Ranges are generated
 * from its symbol table; no ClickHouse source or binary is modified. */
#ifdef TRACE_A
#include "storage_ranges_A.h"
#else
#include "storage_ranges_B.h"
#endif
#define CAPACITY 1000000
struct Record
{
    uint64_t begin_ns;
    uint64_t wait_ns;
    uint64_t hold_ns;
    uint64_t mutex_address;
    uint64_t callsite;
    uint32_t tid;
    uint32_t kind;
};
static struct Record records[CAPACITY];
static _Atomic size_t count;
static _Atomic int closing;
static int (*real_lock)(pthread_mutex_t *);
static int (*real_unlock)(pthread_mutex_t *);
static __thread size_t active_slots[16] __attribute__((tls_model("initial-exec")));
static __thread unsigned active_depth __attribute__((tls_model("initial-exec")));

static uint64_t now_ns(void)
{
    struct timespec value;
    if (clock_gettime(CLOCK_MONOTONIC, &value))
        _exit(120);
    return (uint64_t)value.tv_sec * 1000000000 + value.tv_nsec;
}

__attribute__((constructor)) static void initialize(void)
{
    real_lock = dlvsym(RTLD_NEXT, "__pthread_mutex_lock", "GLIBC_2.17");
    real_unlock = dlvsym(RTLD_NEXT, "__pthread_mutex_unlock", "GLIBC_2.17");
    if (!real_lock || !real_unlock)
        _exit(121);
}

int __pthread_mutex_lock(pthread_mutex_t * mutex)
{
    if (!real_lock)
        _exit(125);
    unsigned kind = 0;
    uintptr_t caller = 0;
    uintptr_t * frame = __builtin_frame_address(0);
    for (unsigned depth = 0; depth < 8; ++depth)
    {
        caller = frame[1] & 0x0000ffffffffffffULL;
        kind = caller >= FIND_BEGIN && caller < FIND_END ? 1
            : caller >= STORE_BEGIN && caller < STORE_END ? 2
            : caller >= DISKFIND_BEGIN && caller < DISKFIND_END ? 3
            : caller >= DISKREAD_BEGIN && caller < DISKREAD_END ? 4
            : caller >= DISKUPDATE_BEGIN && caller < DISKUPDATE_END ? 5 : 0;
        if (kind)
            break;
        if (!((caller >= PUBLIC_BEGIN && caller < PUBLIC_END) || (caller >= STD_BEGIN && caller < STD_END)))
            break;
        uintptr_t previous = frame[0];
        if (previous <= (uintptr_t)frame || previous - (uintptr_t)frame > 1048576 || (previous & 15))
            break;
        frame = (uintptr_t *)previous;
    }
    if (!kind || atomic_load_explicit(&closing, memory_order_relaxed))
        return real_lock(mutex);
    uint64_t before = now_ns();
    int result = real_lock(mutex);
    uint64_t after = now_ns();
    if (!result)
    {
        size_t slot = atomic_fetch_add_explicit(&count, 1, memory_order_relaxed);
        if (slot < CAPACITY)
        {
            records[slot] = (struct Record){before, after-before, 0,
                (uintptr_t)mutex, caller, (uint32_t)syscall(SYS_gettid), kind};
            if (active_depth == 16)
                _exit(127);
            active_slots[active_depth++] = slot;
        }
    }
    return result;
}

int __pthread_mutex_unlock(pthread_mutex_t * mutex)
{
    if (!real_unlock)
        _exit(126);
    if (active_depth && records[active_slots[active_depth-1]].mutex_address == (uintptr_t)mutex)
    {
        struct Record * record = &records[active_slots[--active_depth]];
        record->hold_ns = now_ns() - record->begin_ns - record->wait_ns;
    }
    return real_unlock(mutex);
}

static void write_all(int fd, const void * data, size_t size)
{
    const char * position = data;
    while (size)
    {
        ssize_t written = write(fd, position, size);
        if (written < 0 && errno == EINTR)
            continue;
        if (written <= 0)
            _exit(122);
        position += written;
        size -= written;
    }
}

__attribute__((destructor)) static void finish(void)
{
    atomic_store_explicit(&closing, 1, memory_order_relaxed);
    size_t total = atomic_load_explicit(&count, memory_order_relaxed);
    uint64_t header[2] = {total < CAPACITY ? total : CAPACITY, total > CAPACITY ? total-CAPACITY : 0};
    int fd = open("/out/storage_mutex.bin", O_WRONLY|O_CREAT|O_TRUNC, 0600);
    if (fd < 0)
        _exit(123);
    write_all(fd, header, sizeof(header));
    write_all(fd, records, header[0]*sizeof(struct Record));
    if (close(fd))
        _exit(124);
}
