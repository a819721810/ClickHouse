from pathlib import Path
ROOT=Path(__file__).resolve().parent
script=(ROOT/'run_diagnostic.py').read_text()
script=script.replace("('diagnostic_'", "('mutex_'")
script=script.replace("'order':['A','B','B','A']", "'order':['B','B','B','B']")
script=script.replace("'modes':['threads','short_gil','processes']", "'modes':['mutex_trace']")
script=script.replace("ROOT/'latest_diagnostic.json'", "ROOT/'latest_mutex.json'")
script=script.replace("name='pr117270-tail-'", "name='pr117270-mutex-'")
script=script.replace("result=json.loads((output/'result.json').read_text());assert result['status']=='passed'", "result=json.loads((output/'result.json').read_text());assert result['status']=='passed';assert (output/'cache_mutex.bin').stat().st_size>16")
exec(compile(script, str(ROOT/'run_mutex_trace.py'), 'exec'))
