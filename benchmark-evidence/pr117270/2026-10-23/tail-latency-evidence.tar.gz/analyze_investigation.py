from pathlib import Path
import bisect
import csv
import hashlib
import json
import math
import statistics
import struct
import subprocess

ROOT=Path(__file__).resolve().parent

def read(path):
    return json.loads(path.read_text())

def quantile(values,q):
    values=sorted(values)
    return values[math.ceil(len(values)*q)-1]

def stats(values):
    return {'count':len(values),'median':statistics.median(values),'p95':quantile(values,.95),'p99':quantile(values,.99),'max':max(values)}

def load_phase(name,expected_cases):
    pointer=read(ROOT/('latest_'+name+'.json'))
    assert pointer['status']=='passed'
    directory=Path(pointer['path'])
    manifest=read(directory/'manifest.json')
    assert manifest['status']=='passed' and len(manifest['cases'])==expected_cases
    audits=[json.loads(line) for line in (directory/'container_isolation.jsonl').read_text().splitlines()]
    assert audits and all(not row['running_unpaused_unrelated'] for row in audits)
    for case in manifest['cases']:
        expected='3319c0bf1944237c0ed87eac0fb0affc61a7d609' if case['variant']=='B' else 'dd7889a115c63e16f3bcbc9f843e4633fb2fe1e0'
        assert case['source_sha']==expected and case['status']=='passed'
        assert case['writer_query_finish_count']==2048
    return directory,manifest,len(audits)

phases={};csv_rows=[]
for name,count in [('diagnostic',12),('controls',12),('gc_observation',4),('mutex',4),('storage',8),('io_profile',4),('repeat',16),('serial',8),('interleaved',4),('coalesced',4)]:
    directory,manifest,audits=load_phase(name,count)
    phases[name]={'directory':str(directory),'cases':len(manifest['cases']),'isolation_audits':audits}
    for case in manifest['cases']:
        for kind in ('reader','writer'):
            csv_rows.append({'phase':name,'path':case['path'],'variant':case['variant'],'block':case['block'],'requests':kind,**case[kind+'_summary']})

repeat_summary={}
for phase_name in ('repeat','serial'):
    manifest=read(Path(phases[phase_name]['directory'])/'manifest.json')
    repeat_summary[phase_name]={}
    for variant in ('A','B'):
        selected=[case for case in manifest['cases'] if case['variant']==variant]
        if phase_name=='serial':
            assert all(c['formatting_readback_default']==0 and c['formatting_readback_probes']==[0,0,0,0] for c in selected)
        samples=[json.loads(line) for case in selected for line in (ROOT/case['path']/'samples.jsonl').read_text().splitlines()]
        repeat_summary[phase_name][variant]={kind:{'pooled':stats([s['wall_ms'] for s in samples if s['kind']==kind]),'block_p99_ms':[case[kind+'_summary']['p99_ms'] for case in selected]} for kind in ('reader','writer')}

cache=[]
manifest=read(Path(phases['mutex']['directory'])/'manifest.json')
for case in manifest['cases']:
    directory=ROOT/case['path'];payload=(directory/'cache_mutex.bin').read_bytes()
    count,overflow=struct.unpack_from('<QQ',payload)
    assert len(payload)==16+40*count and overflow==0
    records=[r for r in struct.iter_unpack('<QQQQII',payload[16:]) if case['pressure_started_ns']<=r[0]<=case['pressure_finished_ns']]
    assert len(records)==12288
    data={}
    for kind,label,expected in ((1,'find',10240),(2,'store',2048)):
        selected=[r for r in records if r[-1]==kind]
        assert len(selected)==expected and all(r[2]>0 for r in selected)
        data[label]={'wait_us':stats([r[1]/1000 for r in selected]),'hold_us':stats([r[2]/1000 for r in selected])}
    samples=[json.loads(line) for line in (directory/'samples.jsonl').read_text().splitlines()]
    by_iteration=[[] for _ in range(2048)]
    for sample in samples:by_iteration[sample['iteration']].append(sample)
    starts=[case['pressure_started_ns']+min(s['begin_ns'] for s in group) for group in by_iteration]
    ends=[case['pressure_started_ns']+max(s['end_ns'] for s in group) for group in by_iteration]
    locks=[[] for _ in starts]
    for r in records:
        i=bisect.bisect_right(starts,r[0])-1
        assert i>=0 and r[0]+r[1]+r[2]<=ends[i]
        locks[i].append(r)
    paired=[]
    for i,group in enumerate(by_iteration):
        writer=next(s for s in group if s['kind']=='writer')
        stores=[r for r in locks[i] if r[-1]==2];assert len(stores)==1
        own=[r for r in locks[i] if r[-2]==stores[0][-2]];assert len(own)==2
        assert all(case['pressure_started_ns']+writer['begin_ns']<=r[0] and r[0]+r[1]+r[2]<=case['pressure_started_ns']+writer['end_ns'] for r in own)
        critical=sum(r[1]+r[2] for r in own)/1000
        first=min(r[0] for r in own)
        paired.append({'iteration':i,'wall_ms':writer['wall_ms'],'cache_wait_hold_us':critical,'fraction_percent':critical/(writer['wall_ms']*1000)*100,'before_first_cache_us':(first-case['pressure_started_ns']-writer['begin_ns'])/1000})
    slow=[x for x in paired if x['wall_ms']>1]
    cache.append({'block':case['block'],'reader_p99_ms':case['reader_summary']['p99_ms'],'writer_p99_ms':case['writer_summary']['p99_ms'],'locks':data,'slow_writer_count':len(slow),'slow_cache_us':stats([x['cache_wait_hold_us'] for x in slow]),'slow_cache_fraction_percent':stats([x['fraction_percent'] for x in slow]),'slowest_writer':max(paired,key=lambda x:x['wall_ms'])})

profiles=[]
manifest=read(Path(phases['io_profile']['directory'])/'manifest.json')
for case in manifest['cases']:
    directory=ROOT/case['path'];profile=read(directory/'profile_summary.json');item={'variant':case['variant'],'block':case['block'],'kinds':{}}
    for kind in ('CPU','Real'):
        stacks=[]
        for line in (directory/('profile_'+kind+'.collapsed')).read_text().splitlines():
            stack,count=line.rsplit(' ',1);stacks.append((stack,int(count)))
        total=sum(n for _,n in stacks)
        assert total==sum(int(x['samples']) for x in profile[kind])
        meta=next(x for x in profile['metadata'] if x['kind']==kind);assert int(meta['samples'])==total
        groups={}
        for label,marker in [('parallel_formatting','ParallelFormattingOutputFormat'),('disk_access_storage','DiskAccessStorage'),('effective_cache','EffectiveAccessRightsCache')]:
            n=sum(n for stack,n in stacks if marker in stack);groups[label]={'samples':n,'percent':100*n/total}
        item['kinds'][kind]={'samples':total,'inclusive_overlapping_groups':groups}
    profiles.append(item)

within_run={}
for name,flag_name in [('interleaved','parallel_formatting'),('coalesced','coalesced')]:
    manifest=read(Path(phases[name]['directory'])/'manifest.json')
    cases=[]
    for case in manifest['cases']:
        samples=[json.loads(line) for line in (ROOT/case['path']/'samples.jsonl').read_text().splitlines()]
        for sample in samples:
            assert sample[flag_name]==(sample['iteration']//2+case['block'])%2
            if name=='coalesced':assert sample['send_calls']==(1 if sample[flag_name] else 2)
        if name=='interleaved':assert case['formatting_readback_probes']==[[0]*4,[1]*4]
        item={'variant':case['variant'],'block':case['block'],'groups':{}}
        for kind in ('reader','writer'):
            item['groups'][kind]={str(flag):stats([x['wall_ms'] for x in samples if x['kind']==kind and x[flag_name]==flag]) for flag in (0,1)}
        cases.append(item)
    aggregates={}
    for variant in ('A','B'):
        rows=[json.loads(line) for case in manifest['cases'] if case['variant']==variant for line in (ROOT/case['path']/'samples.jsonl').read_text().splitlines()]
        aggregates[variant]={kind:{str(flag):stats([x['wall_ms'] for x in rows if x['kind']==kind and x[flag_name]==flag]) for flag in (0,1)} for kind in ('reader','writer')}
    within_run[name]={'flag':flag_name,'cases':cases,'aggregate':aggregates}

cpp_names=['src/Access/EffectiveAccessRightsCache.cpp','src/Access/EffectiveAccessRightsCache.h']
cpp_hashes={}
for name in cpp_names:
    payload=(ROOT.parent.parent/name).read_bytes()
    assert payload==subprocess.check_output(['git','show','3319c0bf194:'+name],cwd=ROOT.parent.parent)
    cpp_hashes[name]=hashlib.sha256(payload).hexdigest()
summary={'status':'passed','scope':'512 prepopulated users x 32 role combinations; actual timed concurrency is four readers and one writer. Separate diagnostic phases are never pooled as one A/B experiment.','phases':phases,'unprofiled_repeat_and_serial':repeat_summary,'cache_lock_diagnostic':cache,'profiles':profiles,'within_run_controls':within_run,'cpp_identical_to_3319':cpp_hashes,'conclusion_limits':['The initial historical block lacks per-request stack/lock/host traces; its unique triggering event cannot be reconstructed.','New runs rule out cache critical sections as the main cause in a reproduced slow block; this is not a universal lock-safety guarantee.','A tmpfs baseline can also have a 2ms P99. Neither the new cache nor overlay access-file I/O is necessary for such tails.','An initial snapshot shows nonexclusive host CPU and substantial compressed memory; it does not prove the historical block was caused by a specific app or memory compression.','Profiling includes helper-thread waits; inclusive percentages overlap and do not represent fractions of a request wall clock.']}
(ROOT/'investigation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (ROOT/'per-case-results.csv').open('w',newline='') as output:
    writer=csv.DictWriter(output,fieldnames=list(csv_rows[0]));writer.writeheader();writer.writerows(csv_rows)
print('INVESTIGATION_ANALYSIS_PASS',len(csv_rows),'case-operation rows',sum(x['isolation_audits'] for x in phases.values()),'isolation audits')
