from pathlib import Path
import os
import json
import server_support
original_config=server_support.bench.config
def serial_config(identity):
    config=original_config(identity)
    marker='<max_threads>2</max_threads>'
    assert config.count(marker)==1
    return config.replace(marker,marker+'<output_format_parallel_formatting>0</output_format_parallel_formatting>')
server_support.bench.config=serial_config
script=Path('/scripts/stress_server.py').read_text()
marker="        result['global_calculations_before']=global_calculations()"
injection='''        result['formatting_readback_default']=int(a.query("SELECT toUInt8(getSetting('output_format_parallel_formatting'))")[0])
        result['formatting_readback_probes']=[int(c.query("SELECT toUInt8(getSetting('output_format_parallel_formatting'))",session_check=True)[0]) for c in probes]
        assert result['formatting_readback_default']==0 and result['formatting_readback_probes']==[0]*args.readers
        (out/'effective_config.xml').write_text((f.work/'config.xml').read_text())
        result['actual_server_affinity']=sorted(os.sched_getaffinity(f.proc.pid))
        result['actual_client_affinity']=sorted(os.sched_getaffinity(0))
'''
assert script.count(marker)==1
script=script.replace(marker,injection+marker)
exec(compile(script,'serial_formatting_control','exec'))
