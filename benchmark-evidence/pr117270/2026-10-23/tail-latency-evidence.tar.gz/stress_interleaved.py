from pathlib import Path
import threading
import os
import json
import server_support
format_state=threading.local()
original_encode=server_support.bench.urllib.parse.urlencode
def encode(parameters):
    if hasattr(format_state,'parallel'):
        parameters['output_format_parallel_formatting']=format_state.parallel
    return original_encode(parameters)
server_support.bench.urllib.parse.urlencode=encode
script=Path('/scripts/stress_server.py').read_text()
script=script.replace('                    barrier.wait(timeout=60)', '                    format_state.parallel=(iteration//2+args.block)%2\n                    barrier.wait(timeout=60)')
script=script.replace('wall_ms=(finish-begin)/1e6)', 'wall_ms=(finish-begin)/1e6, parallel_formatting=format_state.parallel)')
marker="        result['global_calculations_before']=global_calculations()"
inject='''        readback=[]
        for flag in (0,1):
            format_state.parallel=flag
            values=[int(c.query("SELECT toUInt8(getSetting('output_format_parallel_formatting'))",session_check=True)[0]) for c in probes]
            assert values==[flag]*args.readers
            readback.append(values)
        del format_state.parallel
        result['formatting_readback_probes']=readback
        (out/'effective_config.xml').write_text((f.work/'config.xml').read_text())
        result['actual_server_affinity']=sorted(os.sched_getaffinity(f.proc.pid))
        result['actual_client_affinity']=sorted(os.sched_getaffinity(0))
'''
assert script.count(marker)==1
script=script.replace(marker,inject+marker)
exec(compile(script,'interleaved_formatting_control','exec'))
