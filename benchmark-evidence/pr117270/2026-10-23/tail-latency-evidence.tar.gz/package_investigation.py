from pathlib import Path
import hashlib
import io
import json
import tarfile
ROOT=Path(__file__).resolve().parent
summary=json.loads((ROOT/'investigation-summary.json').read_text())
assert summary['status']=='passed'
files={}
def add(path,name=None):
    assert path.is_file(),path
    name=name or str(path.relative_to(ROOT))
    assert name not in files,name
    files[name]=path
for path in ROOT.iterdir():
    if path.is_file() and path.suffix in ('.py','.c','.h','.md','.json','.csv') and path.name!='evidence_receipt.json':add(path)
for item in summary['phases'].values():
    directory=Path(item['directory'])
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in ('.json','.jsonl','.log','.bin','.collapsed','.xml','.txt'):add(path)
for path in (ROOT/'build').iterdir():
    if path.is_file() and path.suffix in ('.log','.so') and path.name!='host_process_snapshot.log':add(path)
for directory in (ROOT/'build').iterdir():
    if not directory.is_dir() or not (directory/'manifest.json').exists():continue
    data=json.loads((directory/'manifest.json').read_text())
    if data['status']=='failed':
        add(directory/'manifest.json')
        for path in directory.rglob('test.log'):add(path)
historical=ROOT.parent/'pr117270-optimized2-20261021/build/pressure_matrix_7f945d1b7b'
for path in historical.rglob('*'):
    if path.is_file() and (path.parent==historical or path.parent.name.startswith('u512')) and path.suffix in ('.json','.jsonl','.log'):
        add(path,'historical/'+str(path.relative_to(historical.parent)))
for name in ('src/Access/EffectiveAccessRightsCache.cpp','src/Access/EffectiveAccessRightsCache.h'):
    add(ROOT.parent.parent/name,'source/'+name)
manifest={name:{'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for name,path in sorted(files.items())}
payload=(json.dumps(manifest,indent=2)+'\n').encode()
archive=ROOT/'tail-latency-evidence.tar.gz'
with tarfile.open(str(archive),'w:gz') as tar:
    for name,path in sorted(files.items()):tar.add(str(path),arcname=name,recursive=False)
    member=tarfile.TarInfo('MANIFEST.json');member.size=len(payload);tar.addfile(member,io.BytesIO(payload))
with tarfile.open(str(archive),'r:gz') as tar:
    members=tar.getmembers();assert len(members)==len(files)+1
    for member in members:
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        content=tar.extractfile(member).read()
        if member.name=='MANIFEST.json':assert content==payload
        else:assert hashlib.sha256(content).hexdigest()==manifest[member.name]['sha256']
receipt={'status':'passed','members':len(files)+1,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive':str(archive)}
(ROOT/'evidence_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('INVESTIGATION_EVIDENCE_PASS',json.dumps(receipt))
