from pathlib import Path
from datetime import datetime, timezone
import json
import subprocess
import time
from run_matrix import DOCKER
ROOT=Path(__file__).resolve().parent
with (ROOT/'build/resource_monitor.jsonl').open('w') as output:
    for iteration in range(100):
        state=json.loads(subprocess.check_output([DOCKER,'inspect','pr117270-build-d','--format','{{json .State}}'],text=True,timeout=30))
        record={'utc':datetime.now(timezone.utc).isoformat(),'state':state}
        if state['Running']:
            record['stats']=json.loads(subprocess.check_output([DOCKER,'stats','--no-stream','--format','{{json .}}','pr117270-build-d'],text=True,timeout=30))
        output.write(json.dumps(record)+'\n');output.flush()
        if not state['Running']:break
        time.sleep(30)
