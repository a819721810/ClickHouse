from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
from run_matrix import DOCKER

ROOT = Path(__file__).resolve().parent
status = {'status': 'running', 'started_utc': datetime.now(timezone.utc).isoformat(), 'phase': 'waiting_for_build'}

def save():
    (ROOT / 'pipeline.json').write_text(json.dumps(status, indent=2) + '\n')

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while True:
            block = f.read(16 * 1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()

try:
    save()
    code = subprocess.check_output([DOCKER, 'wait', 'pr117270-build-d'], text=True).strip()
    assert code == '0', ('build exit', code)
    state = json.loads(subprocess.check_output([DOCKER, 'inspect', 'pr117270-build-d', '--format', '{{json .State}}'], text=True))
    assert not state['Running'] and state['ExitCode'] == 0 and not state['OOMKilled'], state
    assert (ROOT / 'build/build_D.exit').read_text().strip() == '0'
    phase = (ROOT / 'build/build_D.phase').read_text().strip()
    assert phase == 'built', phase
    binary = ROOT / 'bin/clickhouse-D'
    assert binary.stat().st_size > 4_000_000_000
    with binary.open('rb') as f:
        assert f.read(4) == b'\x7fELF'
    provenance = json.loads((ROOT / 'provenance.json').read_text())
    source_sha = (ROOT / 'build/build_toolchain.txt').read_text().splitlines()[0]
    assert source_sha == provenance['optimized_sha'], source_sha
    alias = ROOT / 'bin/clickhouse-B'
    assert not alias.exists()
    os.link(str(binary), str(alias))
    receipt = {'state': state, 'phase': phase, 'source_sha': source_sha,
               'binary': str(binary), 'binary_sha256': digest(binary), 'binary_bytes': binary.stat().st_size,
               'baseline_sha256': digest(ROOT / 'bin/clickhouse-A-runtime'),
               'input_alias': 'clickhouse-B is a hard link to optimized clickhouse-D; original PR binary is preserved in the previous benchmark root'}
    (ROOT / 'build_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    for label, script in [('validation', 'run_validation.py'), ('combinations', 'run_combination_matrix.py'), ('pressure', 'run_pressure_matrix.py'), ('large_acl', 'run_matrix.py'), ('report', 'make_report.py')]:
        status['phase'] = label; save()
        print('PIPELINE_START', label, flush=True)
        with (ROOT / 'build' / ('test_' + label + '.log')).open('w') as log:
            subprocess.run(['python3', str(ROOT / script)], check=True, stdout=log, stderr=subprocess.STDOUT)
        print('PIPELINE_PASS', label, flush=True)
    status.update(status='passed', phase='complete')
except BaseException as error:
    status.update(status='failed', error=repr(error))
    raise
finally:
    status['updated_utc'] = datetime.now(timezone.utc).isoformat(); save()
