from pathlib import Path
import server_support

original_config = server_support.bench.config
def profiling_config(identity):
    return original_config(identity).replace(
        '<query_profiler_cpu_time_period_ns>0</query_profiler_cpu_time_period_ns>',
        '<query_profiler_cpu_time_period_ns>100000</query_profiler_cpu_time_period_ns>').replace(
        '<query_profiler_real_time_period_ns>0</query_profiler_real_time_period_ns>',
        '<query_profiler_real_time_period_ns>100000</query_profiler_real_time_period_ns>').replace(
        '</clickhouse>',
        '<trace_log><database>system</database><table>trace_log</table><flush_interval_milliseconds>1000</flush_interval_milliseconds></trace_log></clickhouse>')
server_support.bench.config = profiling_config

script = Path('/scripts/stress_combinations.py').read_text()
injection = '''        a.query('SYSTEM FLUSH LOGS')
        predicate="startsWith(query_id,'"+f.identity+"_combo_')"
        result['diagnostic_only']=True
        result['sampling_period_ns']=100000
        result['profile_metadata']=a.rows("SELECT toString(trace_type) AS kind,count() AS samples,uniqExact(query_id) AS queries,min(event_time_microseconds) AS first,max(event_time_microseconds) AS last FROM system.trace_log WHERE "+predicate+" GROUP BY trace_type")
        assert any(row['kind']=='CPU' and int(row['samples'])>100 for row in result['profile_metadata']),result['profile_metadata']
        for kind in ('CPU','Real'):
            where=predicate+" AND trace_type='"+kind+"'"
            result['top_'+kind]=a.rows("SELECT count() AS samples,demangle(addressToSymbol(trace[1])) AS function FROM system.trace_log WHERE "+where+" GROUP BY function ORDER BY samples DESC LIMIT 30 SETTINGS allow_introspection_functions=1")
            result['stacks_'+kind]=a.rows("SELECT count() AS samples,arrayStringConcat(arrayMap(x->demangle(addressToSymbol(x)),trace),'\\n    ') AS stack FROM system.trace_log WHERE "+where+" GROUP BY trace ORDER BY samples DESC LIMIT 15 SETTINGS allow_introspection_functions=1")
            collapsed=a.query("SELECT concat(arrayStringConcat(arrayReverse(arrayMap(x->demangle(addressToSymbol(x)),trace)),';'),' ',toString(count())) FROM system.trace_log WHERE "+where+" GROUP BY trace SETTINGS allow_introspection_functions=1 FORMAT TSVRaw")[0]
            (out/('profile_'+kind+'.collapsed')).write_text(collapsed+'\\n')
            result['cache_'+kind]=a.rows("SELECT count() AS samples,countIf(arrayExists(x->position(addressToSymbol(x),'EffectiveAccessRightsCache')>0,trace)) AS cache_frames,countIf(position(addressToSymbol(trace[1]),'EffectiveAccessRightsCache')>0) AS cache_leaf FROM system.trace_log WHERE "+where+" SETTINGS allow_introspection_functions=1")
        (out/'profile_summary.json').write_text(json.dumps({key:value for key,value in result.items() if key.startswith(('profile_','top_','stacks_','cache_'))},indent=2)+'\\n')
'''
assert script.count("        result['summaries']={}") == 1
script = script.replace("        result['summaries']={}", injection + "        result['summaries']={}")
exec(compile(script, 'diagnostic_cache_cpu_profile', 'exec'))
