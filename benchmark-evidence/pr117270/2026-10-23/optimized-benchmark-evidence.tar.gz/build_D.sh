#!/usr/bin/env bash
set -euo pipefail
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'printf "%s\n" "$?" > /logs/build_D.exit' EXIT
cd /build
git config --global --add safe.directory /build
{
    git rev-parse HEAD
    clang-22 --version
    clang++-22 --version
    ld.lld-22 --version
    cmake --version
    sccache --version
} > /logs/build_toolchain.txt 2>&1

export SCCACHE_DIR=/build/build/sccache
export SCCACHE_CACHE_SIZE=16G
export SCCACHE_IDLE_TIMEOUT=7200
unset SCCACHE_BUCKET SCCACHE_S3_KEY_PREFIX SCCACHE_S3_NO_CREDENTIALS SCCACHE_S3_READ_ONLY
export SCCACHE_ERROR_LOG=/logs/sccache.log
export SCCACHE_LOG=warn

cmake -S /build -B /build/build -G Ninja \
    -DCMAKE_BUILD_TYPE=RelWithDebInfo \
    -DCMAKE_C_COMPILER=clang-22 -DCMAKE_CXX_COMPILER=clang++-22 \
    -DCMAKE_TOOLCHAIN_FILE=/build/cmake/linux/toolchain-aarch64.cmake \
    -DCOMPILER_CACHE=sccache \
    -DENABLE_THINLTO=1 -DSANITIZE= \
    -DENABLE_CHECK_HEAVY_BUILDS=1 \
    -DBUILD_STRIPPED_BINARY=1 -DENABLE_CLICKHOUSE_SELF_EXTRACTING=1 \
    -DENABLE_BUILD_PROFILING=1 -DENABLE_TESTS=0 -DENABLE_LEXER_TEST=0 -DENABLE_UTILS=0 \
    -DCMAKE_FIND_PACKAGE_NO_PACKAGE_REGISTRY=ON \
    -DCMAKE_INSTALL_PREFIX=/usr -DCMAKE_INSTALL_SYSCONFDIR=/etc -DCMAKE_INSTALL_LOCALSTATEDIR=/var \
    -DCMAKE_SKIP_INSTALL_ALL_DEPENDENCY=ON -DSPLIT_DEBUG_SYMBOLS=ON -DBUILD_STANDALONE_KEEPER=1 \
    -DCLICKHOUSE_OFFICIAL_BUILD=1 \
    -DPARALLEL_COMPILE_JOBS=16 -DPARALLEL_LINK_JOBS=1 \
    '-DCMAKE_EXE_LINKER_FLAGS_RELWITHDEBINFO=-Wl,--thinlto-jobs=4 -Wl,--threads=16 -Wl,--thinlto-cache-dir=/build/build/thinlto-cache' \
    > /logs/configure_D.log 2>&1
printf 'configured\n' > /logs/build_D.phase
ninja -C /build/build clickhouse > /logs/build_D.log 2>&1
sccache --show-stats > /logs/sccache_stats.txt 2>&1
cp /build/build/programs/clickhouse /out/clickhouse-D
printf 'built\n' > /logs/build_D.phase
