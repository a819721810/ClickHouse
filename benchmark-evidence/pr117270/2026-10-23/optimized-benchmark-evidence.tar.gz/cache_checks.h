#include <atomic>
#include <new>

namespace Checks
{
void require(bool condition, const char * message)
{
    if (!condition)
        throw std::runtime_error(message);
}

std::atomic<size_t> allocated_blocks{0};

template <typename T>
struct TrackingAllocator
{
    using value_type = T;
    TrackingAllocator() = default;
    template <typename U>
    TrackingAllocator(const TrackingAllocator<U> &) {}
    T * allocate(size_t count)
    {
        auto result = std::allocator<T>{}.allocate(count);
        ++allocated_blocks;
        return result;
    }
    void deallocate(T * pointer, size_t count)
    {
        --allocated_blocks;
        std::allocator<T>{}.deallocate(pointer, count);
    }
    template <typename U>
    bool operator ==(const TrackingAllocator<U> &) const { return true; }
};

Micro::Alive tracked()
{
    Micro::Alive result;
    result.user = std::allocate_shared<DB::User>(TrackingAllocator<DB::User>{});
    result.roles = std::allocate_shared<DB::EnabledRolesInfo>(TrackingAllocator<DB::EnabledRolesInfo>{});
    result.access = std::allocate_shared<DB::AccessRights>(TrackingAllocator<DB::AccessRights>{});
    result.implicit = std::allocate_shared<DB::AccessRights>(TrackingAllocator<DB::AccessRights>{});
    return result;
}

void run()
{
    {
        DB::EffectiveAccessRightsCache cache;
        Micro::Alive first;
        std::vector<Micro::Alive> versions(16);
        for (size_t bits = 0; bits < 16; ++bits)
        {
            auto & value = versions[bits];
            value.user = first.user;
            value.roles = first.roles;
            DB::ImplicitExpansionSettings settings{bool(bits & 1), bool(bits & 2), bool(bits & 4), bool(bits & 8)};
            cache.store(Micro::id(0), value.user, value.roles, settings, value.access, value.implicit);
        }
        for (size_t bits = 0; bits < 16; ++bits)
        {
            DB::ImplicitExpansionSettings settings{bool(bits & 1), bool(bits & 2), bool(bits & 4), bool(bits & 8)};
            auto result = cache.find(Micro::id(0), first.user, first.roles, settings);
            require(result && result->access == versions[bits].access, "Settings snapshots evicted or mixed");
        }
        require(!cache.find(Micro::id(1), first.user, first.roles, {}), "Different user ID shared");
        auto changed_user = std::make_shared<DB::User>();
        require(!cache.find(Micro::id(0), changed_user, first.roles, {}), "New user snapshot hit old result");
        auto changed_access = std::make_shared<DB::AccessRights>();
        auto changed_implicit = std::make_shared<DB::AccessRights>();
        cache.store(Micro::id(0), changed_user, first.roles, {}, changed_access, changed_implicit);
        require(!cache.find(Micro::id(0), first.user, first.roles, {}), "Old live user snapshot received new version");
        auto changed = cache.find(Micro::id(0), changed_user, first.roles, {});
        require(changed && changed->access == changed_access && changed->access_with_implicit == changed_implicit, "Updated user snapshot lost its result");
        cache.store(Micro::id(0), first.user, first.roles, {}, versions[0].access, versions[0].implicit);
        require(!cache.find(Micro::id(0), changed_user, first.roles, {}), "New live user snapshot received old version");
        auto changed_roles = std::make_shared<DB::EnabledRolesInfo>();
        require(!cache.find(Micro::id(0), first.user, changed_roles, {}), "New roles snapshot hit old result");
    }
    {
        DB::EffectiveAccessRightsCache cache;
        alignas(DB::User) unsigned char storage[sizeof(DB::User)];
        auto destroy = [](const DB::User * value) { value->~User(); };
        Micro::Alive value;
        value.user = DB::UserPtr(new (storage) DB::User, destroy);
        Micro::store(cache, 0, value);
        value.user.reset();
        value.user = DB::UserPtr(new (storage) DB::User, destroy);
        require(!cache.find(Micro::id(0), value.user, value.roles, {}), "Reused snapshot address produced a hit");
        Micro::store(cache, 0, value);
        Micro::find(cache, 0, value);
    }
    {
        DB::EffectiveAccessRightsCache cache;
        std::vector<Micro::Alive> retired;
        retired.reserve(4096);
        for (size_t i = 0; i < 4096; ++i)
        {
            retired.push_back(tracked());
            Micro::store(cache, i, retired.back());
        }
        auto live = tracked();
        Micro::store(cache, 100000, live);
        retired.clear();
        require(allocated_blocks > 4, "Weak-reference cleanup precondition not exercised");
        for (size_t i = 0; i < 4096; ++i)
        {
            Micro::store(cache, 100000, live);
            Micro::find(cache, 100000, live);
        }
        require(allocated_blocks == 4, "Incremental sweeping did not release retired control blocks");
    }
    require(allocated_blocks == 0, "Cache retained control blocks after destruction");
    {
        DB::EffectiveAccessRightsCache cache;
        std::vector<Micro::Alive> values(4);
        for (auto & value : values)
        {
            value.user = values.front().user;
            value.roles = values.front().roles;
        }
        std::atomic<bool> valid{true};
        std::barrier start(4);
        std::vector<std::thread> threads;
        for (size_t thread = 0; thread < 4; ++thread)
        {
            threads.emplace_back([&, thread]
            {
                start.arrive_and_wait();
                for (size_t iteration = 0; iteration < 20000; ++iteration)
                {
                    Micro::store(cache, 0, values[thread]);
                    auto found = cache.find(Micro::id(0), values[thread].user, values[thread].roles, {});
                    bool matches = false;
                    if (found)
                    {
                        for (const auto & candidate : values)
                            matches |= found->access == candidate.access && found->access_with_implicit == candidate.implicit;
                    }
                    if (!matches)
                        valid = false;
                }
            });
        }
        for (auto & thread : threads)
            thread.join();
        require(valid, "Concurrent publication returned inconsistent results");
    }
    {
        DB::EffectiveAccessRightsCache cache;
        std::vector<Micro::Alive> values(4);
        for (auto & value : values)
            value.roles = values.front().roles;
        std::atomic<bool> valid{true};
        std::barrier start(4);
        std::vector<std::thread> threads;
        for (size_t thread = 0; thread < 4; ++thread)
        {
            threads.emplace_back([&, thread]
            {
                start.arrive_and_wait();
                for (size_t iteration = 0; iteration < 20000; ++iteration)
                {
                    Micro::store(cache, 0, values[thread]);
                    auto found = cache.find(Micro::id(0), values[thread].user, values[thread].roles, {});
                    if (found && (found->access != values[thread].access || found->access_with_implicit != values[thread].implicit))
                        valid = false;
                }
            });
        }
        for (auto & thread : threads)
            thread.join();
        require(valid, "Concurrent user versions mixed their permissions");
    }
    std::cout << "CACHE_INVARIANTS_PASS settings=16 address_reuse=1 retired_entries=4096 concurrent_operations=320000 user_version_replacement=1\n";
}
}
