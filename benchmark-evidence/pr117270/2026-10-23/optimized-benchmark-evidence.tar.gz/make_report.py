from pathlib import Path
import csv
import hashlib
import json
import math
import statistics
from report_support import normalized_flags

ROOT = Path(__file__).resolve().parent

def read(path):
    return json.loads(path.read_text())

def accepted(name):
    pointer = read(ROOT / ('latest_' + name + '.json'))
    assert pointer['status'] == 'passed'
    directory = Path(pointer['path'])
    manifest = read(directory / 'manifest.json')
    assert manifest['status'] == 'passed'
    assert not manifest.get('excluded_from_final_report', False)
    checks = [json.loads(line) for line in (directory / 'container_isolation.jsonl').read_text().splitlines()]
    assert checks and all(not c['running_unpaused_unrelated'] for c in checks)
    return directory, manifest, len(checks)

def stat(values):
    values = sorted(values)
    return statistics.median(values), values[math.ceil(.95 * len(values)) - 1]

def main():
    provenance = read(ROOT / 'provenance.json')
    validation_dir, validation, validation_checks = accepted('validation')
    combo_dir, combo, combo_checks = accepted('combination_matrix')
    large_dir, large, large_checks = accepted('matrix')
    pressure_dir, pressure, pressure_checks = accepted('pressure_matrix')
    assert len(validation['cases']) == 4 and len(combo['cases']) == 16
    assert len(large['completed_runs']) == 24 and len(pressure['cases']) == 8
    build = read(ROOT / 'build_receipt.json')
    assert build['state']['ExitCode'] == 0 and not build['state']['OOMKilled']
    assert build['phase'] == 'built' and build['source_sha'] == provenance['optimized_sha']
    assert 'OPTIMIZED_COMPONENT_PASS sanitized' in (ROOT / 'build/test_component_sanitized_final2.log').read_text()
    sanitized_hashes = read(ROOT / 'build/component_sanitized_final2/source_hashes.json')
    for name, digest in sanitized_hashes.items():
        assert hashlib.sha256((ROOT.parent.parent / name).read_bytes()).hexdigest() == digest
    runs = [read(ROOT / path / 'result.json') for path in large['completed_runs']]
    assert len({r['dataset']['fixture_sha256'] for r in runs}) == 1
    options = {}
    for label in ('A', 'B'):
        selected = [r for r in runs if r['variant'] == label]
        assert len(selected) == 12
        expected = provenance['baseline_sha'] if label == 'A' else provenance['optimized_sha']
        assert all(r['source_sha'] == expected for r in selected)
        assert all(r['build_options'] == selected[0]['build_options'] for r in selected)
        options[label] = selected[0]['build_options']
    differences = {}
    for key in options['A'].keys() | options['B'].keys():
        if key.startswith(('GIT_', 'VERSION_')):
            continue
        a, b = options['A'].get(key), options['B'].get(key)
        if key in ('C_FLAGS', 'CXX_FLAGS', 'LINK_FLAGS'):
            a, b = normalized_flags(a or ''), normalized_flags(b or '')
        if a != b:
            differences[key] = {'A': a, 'B': b}
    (ROOT / 'build_comparison.json').write_text(json.dumps(differences, indent=2) + '\n')
    assert not differences, differences
    aggregate = read(large_dir / 'summary.json')
    rows = {(r['mode'], r['sessions'], r['variant'], r['operation']): r for r in aggregate['summaries']}
    all_samples = []
    lines = [
        '## Local validation of indexed effective access rights cache', '',
        'Related: https://github.com/ClickHouse/ClickHouse/pull/117270', '',
        f"A is the exact parent `{provenance['baseline_sha']}` (official ARM Release artifact). B in this report is the optimized local commit `{provenance['optimized_sha']}`. The previous PR binary `{provenance['previous_pr_sha']}` is historical evidence only and is not pooled into the fresh A/B samples.", '',
        'The implementation replaces per-user vector scans with a hash index over user UUID, the exact immutable `EnabledRolesInfo` snapshot, and all four `ImplicitExpansionSettings` values. Each slot keeps one user snapshot, checked exactly before a hit; user snapshot changes reuse the allocated slot; overlapping versions may miss but cannot share mismatched results. Each `store` examines at most two entries for expiry using a stable list cursor. Snapshot weak references are still validated on a hit, including address reuse. Average index lookup and insertion are constant time; normal hash-table rehashing can still take linear time.', '',
        '### Method', '',
        '- Native Linux ARM64 in Docker Desktop on Apple M5 Max, 18 host CPUs / 128 GiB RAM; Docker VM 90 GiB. Each full-server test container has four vCPUs, cpuset `0-3`, 6 GiB RAM, and no external network.',
        '- Fresh sequential A/B/B/A blocks; two warm-up and ten measured grant/revoke pairs per block, hence twenty measured samples per operation and variant. Client loopback wall time includes the complete local access change. Validation and setup are outside the timed section.',
        '- No compilation overlaps measurements. Eleven unrelated containers stay paused and two stay stopped; state is audited before, after, and about every five seconds during cases. The macOS host is not claimed to be exclusive.',
        '- Exact runtime identity is asserted through `system.build_options.GIT_HASH`. Clang/LLD 22.1.8, `RelWithDebInfo`, optimization, ThinLTO and reported feature options match after normalizing linker worker/cache and two compiler-rt archive path differences. Raw options remain in each result.',
        '- These are local measurements, not performance-CI or production measurements. They exclude `ON CLUSTER`, Keeper and distributed DDL queue delays.', '',
        '### Many distinct role combinations: fresh A/B', '',
        'One user, small ACL, one persistent named HTTP session visits every subset of 5/8/10/12 actual roles. The existing context cache retains 32/256/1024/4096 distinct role combinations. Thus these are combination/context counts, not thousands of roles or TCP connections. Updating the user requires one calculation per combination; this intentionally removes same-role reuse and stresses cache overhead.', '',
        '| Combinations | Operation | A median / P95 ms | Optimized B median / P95 ms | B / A |',
        '|---:|---|---:|---:|---:|',
    ]
    combo_summary = []
    for count in (32, 256, 1024, 4096):
        for operation in ('GRANT', 'REVOKE'):
            groups = {}
            for label in ('A', 'B'):
                selected = [r for r in combo['cases'] if r['variant'] == label and r['combinations_seeded'] == count]
                assert len(selected) == 2
                samples = [s for r in selected for s in r['measurements'] if not s['warmup'] and s['operation'] == operation]
                assert len(samples) == 20
                groups[label] = stat([s['wall_ms'] for s in samples])
                block_medians = {r['block']: statistics.median(s['wall_ms'] for s in r['measurements'] if not s['warmup'] and s['operation'] == operation) for r in selected}
                combo_summary.append({'combinations': count, 'operation': operation, 'variant': label, 'median_ms': groups[label][0], 'p95_ms': groups[label][1], 'block_medians_ms': block_medians, 'cpu_median_ms': statistics.median(int(s['server']['cpu_us']) / 1000 for s in samples)})
                if label == 'B':
                    assert all(int(s['server']['calculations']) == count and int(s['server']['cache_hits']) == 0 for s in samples)
                for r in selected:
                    for s in r['measurements']:
                        if s['operation'] != operation:
                            continue
                        all_samples.append(dict(suite='combinations', case=str(count), variant=label, block=r['block'], operation=s['operation'], warmup=s['warmup'], wall_ms=s['wall_ms'], cpu_ms=int(s['server']['cpu_us']) / 1000, calculations=s['server']['calculations'], cache_hits=s['server']['cache_hits']))
            a, b = groups['A'], groups['B']
            lines.append(f'| {count} | `{operation}` | {a[0]:.3f} / {a[1]:.3f} | {b[0]:.3f} / {b[1]:.3f} | {b[0]/a[0]:.3f}x |')
    combo_by_key = {(r['combinations'],r['operation'],r['variant']):r for r in combo_summary}
    overheads = [100*(combo_by_key[(count,op,'B')]['median_ms']/combo_by_key[(count,op,'A')]['median_ms']-1) for count in (256,1024,4096) for op in ('GRANT','REVOKE')]
    lines += ['', f'The current repeat still measures {min(overheads):.1f}% to {max(overheads):.1f}% median overhead for 256–4096 zero-reuse combinations. The quadratic scan penalty is removed, but the result is not zero overhead or a universal non-regression. This repeat takes precedence over the smaller differences in the earlier replication.', '',
              'Historical comparison, kept separate: before this change, the old PR measured 45.630 / 44.699 ms for 1024 combinations and 554.034 / 542.299 ms for 4096 combinations (`GRANT` / `REVOKE` medians), versus its contemporaneous parent 24.018 / 22.756 ms and 91.781 / 85.669 ms. The fresh table above is the evidence for the optimized version; historical numbers are not a paired B-versus-old-PR experiment.', '',
              'An earlier accepted replication of this same final binary on 2026-10-21 had median B/A ratios from 0.989 to 1.019, but its 4096-combination `REVOKE` P95 was 111.830 ms versus A 83.867 ms. The slow block also used more CPU; its cause was not identified. Thus removal of the quadratic median slowdown is not a claim that every tail percentile improves. The earlier replication is retained separately in `previous_accepted_runs.json`; it is not pooled with the primary table.', '',
              '### Production-scale synthetic ACL: fresh A/B', '',
              'Identical synthetic fixture in all 24 runs: 75,123 direct privilege rows across 15,580 table paths, plus one enabled role with 471 rows across 465 paths. It matches recorded aggregate scale, not the exact production topology; it contains no column grants, partial revokes or grant-option distribution. `shared` uses identical context parameters; `distinct` changes each named session default database while keeping effective roles identical. Session counts are not exact counts of retained `ContextAccess` objects.', '',
              '| Context parameters | Sessions | Operation | A median / P95 ms | Optimized B median / P95 ms | A / B speedup |',
              '|---|---:|---|---:|---:|---:|---:|']
    for mode in ('shared', 'distinct'):
        for count in (1, 10, 50):
            for operation in ('GRANT', 'REVOKE'):
                a, b = (rows[(mode, count, label, operation)] for label in ('A', 'B'))
                assert a['samples'] == b['samples'] == 20
                assert b['calculations_range'] == [1, 1]
                expected_hits = count if mode == 'distinct' else 0
                assert b['cache_hits_range'] == [expected_hits, expected_hits], b
                lines.append(f"| {mode} | {count} | `{operation}` | {a['client_median_ms']:.3f} / {a['client_p95_ms']:.3f} | {b['client_median_ms']:.3f} / {b['client_p95_ms']:.3f} | {a['client_median_ms']/b['client_median_ms']:.2f}x |")
    for r in runs:
        for s in r['measurements']:
            all_samples.append(dict(suite='large_acl', case=f"{r['context_mode']}_{r['sessions']}", variant=r['variant'], block=r['block'], operation=s['operation'], warmup=s['warmup'], wall_ms=s['client_seconds']*1000, cpu_ms=(int(s['server']['user_cpu_us'])+int(s['server']['system_cpu_us']))/1000, calculations=s['server']['calculations'], cache_hits=s['server']['cache_hits']))
    lines += ['', 'Optimized B recorded one calculation and N hits in every distinct-context update (including N=1), and one calculation with zero hits in the shared controls. These events were introduced by the PR and do not exist on A; zero raw A event values must not be read as zero calculation work. All existing sessions check the changed permission and continue to reject unrelated writes after every operation. Already-shared contexts are a control and should not be advertised as a general connection-count speedup.', '',
              '### Correctness and concurrent maintenance checks', '',
              '- Unmodified `05054_effective_access_rights_cache.sh` and its reference pass on the optimized full server, including both cache-hit assertions.',
              '- New `05055_effective_access_rights_role_permissions.sh` passes: four established sessions with A/A/B/A+B roles are warmed first; direct role permission grants and revokes take effect in those sessions while `SHOW CREATE USER` stays unchanged. Both actual `SELECT` execution and `CHECK GRANT` are checked, with unrelated `INSERT` denied.',
              '- Additional 1/10/50-session and mixed-role checks pass; authentication-method `GRANTS` isolation checks pass in full-first and restricted-first order.',
              '- ASan/UBSan component checks on the committed cache implementation pass: all sixteen settings combinations, exact snapshot identity, reused object addresses, eventual release of 4096 retired entries, and 320,000 concurrent operations across identical and different live user snapshots. Payloads are simplified in this component check; it is not a sanitizer build of the full server.',
              '- Multi-user maintenance matrix also uses A/B/B/A, 64 users x 16 combinations and 512 x 32 combinations, with four readers and 2048 unrelated writer updates per block. Reader success is checked by returned results; reader query logging is disabled. Writer completion is checked through `QueryFinish`. Short concurrent runs do not establish a universal P99 guarantee.', '',
              '| Users x combinations | Requests | A median / P99 ms | Optimized B median / P99 ms |',
              '|---|---|---:|---:|']
    pressure_aggregate = []
    for users, combinations in ((64,16), (512,32)):
        for kind in ('reader', 'writer'):
            stats = {}
            for label in ('A', 'B'):
                selected = [r for r in pressure['cases'] if r['users'] == users and r['combinations'] == combinations and r['variant'] == label]
                assert len(selected) == 2
                samples = [s['wall_ms'] for r in selected for s in (json.loads(line) for line in (ROOT / r['path'] / 'samples.jsonl').read_text().splitlines()) if s['kind'] == kind]
                assert len(samples) == (16384 if kind == 'reader' else 4096)
                samples.sort()
                stats[label] = (statistics.median(samples), samples[math.ceil(.99*len(samples))-1])
                pressure_aggregate.append({'users':users, 'combinations':combinations, 'kind':kind, 'variant':label, 'samples':len(samples), 'median_ms':stats[label][0], 'p99_ms':stats[label][1], 'max_ms':max(samples)})
            a, b = stats['A'], stats['B']
            lines.append(f'| {users} x {combinations} | {kind} | {a[0]:.3f} / {a[1]:.3f} | {b[0]:.3f} / {b[1]:.3f} |')
    pressure_by_key = {(r['users'],r['kind'],r['variant']):r for r in pressure_aggregate}
    reader_ratio = pressure_by_key[(512,'reader','B')]['p99_ms']/pressure_by_key[(512,'reader','A')]['p99_ms']
    writer_ratio = pressure_by_key[(512,'writer','B')]['p99_ms']/pressure_by_key[(512,'writer','A')]['p99_ms']
    lines += ['', f'The 512-user repeat includes a slow B block: pooled reader P99 is {reader_ratio:.2f}x A and writer P99 is {writer_ratio:.2f}x A. The cause is not identified. All functional checks and writer completions passed, but this observation prevents a claim of stable tail-latency improvement. Per-block results remain in the raw manifest and summary.', '']
    profile_analysis = read(ROOT / 'cpu-profile-analysis.json')
    assert profile_analysis['diagnostic_only']
    assert profile_analysis['minimum_effective_period_ns'] == 1000000
    lines += ['', '### Separate CPU diagnostic', '',
              'A separate 4096-combination profile confirms that absolute CPU is dominated by permission-tree construction, implicit expansion and release. Visible cache frames account for 14/2047 CPU samples (0.68%) in B, but this is not an upper bound on all cache cost because inlining and lifecycle work may be charged elsewhere. It does not precisely explain the remaining 5–7% overhead or the concurrent pressure-tail observation.', '',
              'Both variants requested a 100-microsecond sampling period; `Timer::set` clamps the effective period to at least one millisecond in both source versions. These diagnostic timings are excluded from the A/B tables. See `cpu-profile-analysis.md`, `cpu-profile-analysis.json` and the complete collapsed stacks for evidence and limitations.', '']
    windows = {}
    for name, directory in [('validation',validation_dir),('combinations',combo_dir),('large_acl',large_dir),('pressure',pressure_dir)]:
        audit = [json.loads(line) for line in (directory / 'container_isolation.jsonl').read_text().splitlines()]
        windows[name] = {'first_audit_utc':audit[0]['utc'], 'last_audit_utc':audit[-1]['utc'], 'methods':sorted({r.get('snapshot_method', 'docker_ps_then_inspect') for r in audit})}
    lines += ['', f'All {validation_checks + combo_checks + large_checks + pressure_checks} container isolation audits passed. The interrupted `matrix_2e9ab2fab1` is excluded in full; the recovered monitor uses one daemon snapshot so normal removal of a disposable runner cannot break a separate inspection step. Per-suite UTC measurement windows and actual audit methods are recorded in `summary.json`; methods are not applied retroactively to earlier runs.', '',
              'See `summary.json`, `benchmark-samples.csv`, raw manifests, per-case `result.json`, and `build_receipt.json` for block variation, CPU, counters, source identity and artifact hashes. No claim is made here about CI approval, universal tail-latency behavior, or production deployment.']
    with (ROOT / 'benchmark-samples.csv').open('w', newline='') as f:
        assert len(all_samples) == 960
        assert sum(not s['warmup'] for s in all_samples) == 800
        writer = csv.DictWriter(f, fieldnames=list(all_samples[0]))
        writer.writeheader(); writer.writerows(all_samples)
    summary = {'provenance': provenance, 'combinations': combo_summary, 'large_acl': aggregate['summaries'], 'pressure': [{'variant': r['variant'], 'block': r['block'], 'users': r['users'], 'combinations': r['combinations'], 'reader_summary': r['reader_summary'], 'writer_summary': r['writer_summary']} for r in pressure['cases']], 'accepted_directories': {k: str(v) for k,v in [('validation',validation_dir),('combinations',combo_dir),('large_acl',large_dir),('pressure',pressure_dir)]}, 'isolation_audits': validation_checks + combo_checks + large_checks + pressure_checks}
    summary.update(measurement_windows=windows, pressure_aggregate=pressure_aggregate)
    (ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    (ROOT / 'benchmark-for-pr.md').write_text('\n'.join(lines) + '\n')
    print('OPTIMIZED_REPORT_PASS', len(all_samples), 'samples', summary['isolation_audits'], 'isolation audits')

if __name__ == '__main__':
    main()
