from pathlib import Path
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent
assert json.loads((ROOT / 'pipeline.json').read_text())['status'] == 'passed'
summary = json.loads((ROOT / 'summary.json').read_text())
files = {}

def add(path, name=None):
    assert path.is_file(), path
    name = name or str(path.relative_to(ROOT))
    assert name not in files
    files[name] = path

for path in ROOT.iterdir():
    if path.is_file() and path.suffix in ('.py', '.h', '.sh', '.patch', '.md', '.json', '.csv', '.diff') and path.name != 'evidence_receipt.json':
        add(path)
directories = list(summary['accepted_directories'].values())
profiles = json.loads((ROOT / 'latest_profiles.json').read_text())
assert profiles['status'] == 'passed'
directories.append(profiles['path'])
previous = json.loads((ROOT / 'previous_accepted_runs.json').read_text())
directories.extend(item['path'] for item in previous.values())
for value in directories:
    directory = Path(value)
    for path in directory.rglob('*'):
        if path.is_file() and (path.suffix in ('.json', '.jsonl', '.csv', '.collapsed') or path.name in ('test.log', 'original.stdout', 'original.stderr', 'expected.stdout')):
            add(path)
for name in ('configure_D.log', 'build_D.log', 'build_D.container.log', 'build_D.phase', 'build_D.exit', 'build_toolchain.txt', 'sccache_stats.txt', 'resource_monitor.jsonl', 'test_pipeline.log', 'test_validation.log', 'test_combinations.log', 'test_pressure.log', 'test_large_acl.log', 'test_large_acl_rerun_2026-10-23.log', 'test_finish_validation_2026-10-23.log', 'test_combinations_repeat_2026-10-23.log', 'test_pressure_repeat_2026-10-23.log', 'test_report_2026-10-23.log', 'test_report_explicit_limits_2026-10-23.log', 'test_report_final_2026-10-23.log', 'test_profiles_2026-10-23.log', 'test_profile_analysis_2026-10-23.log', 'test_component_sanitized_final2.log'):
    add(ROOT / 'build' / name)
add(ROOT / 'build/component_sanitized_final2/source_hashes.json')
add(ROOT / 'shims/Core/UUID.h')
for name in ('src/Access/EffectiveAccessRightsCache.h', 'src/Access/EffectiveAccessRightsCache.cpp', 'tests/queries/0_stateless/05055_effective_access_rights_role_permissions.sh', 'tests/queries/0_stateless/05055_effective_access_rights_role_permissions.reference'):
    add(ROOT.parent.parent / name, 'source/' + name)

manifest = {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in sorted(files.items())}
payload = (json.dumps(manifest, indent=2) + '\n').encode()
archive = ROOT / 'pr117270-optimized-evidence.tar.gz'
with tarfile.open(str(archive), 'w:gz') as tar:
    for name, path in sorted(files.items()):
        tar.add(str(path), arcname=name, recursive=False)
    info = tarfile.TarInfo('MANIFEST.json'); info.size = len(payload)
    tar.addfile(info, io.BytesIO(payload))
with tarfile.open(str(archive), 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(files) + 1
    for member in members:
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        content = tar.extractfile(member).read()
        if member.name == 'MANIFEST.json':
            assert content == payload
        else:
            assert hashlib.sha256(content).hexdigest() == manifest[member.name]['sha256']
receipt = {'status': 'passed', 'members': len(members), 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'archive': str(archive)}
(ROOT / 'evidence_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('EVIDENCE_PASS', json.dumps(receipt))
