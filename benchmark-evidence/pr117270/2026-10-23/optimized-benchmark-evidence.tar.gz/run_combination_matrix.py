from pathlib import Path
import importlib.util
import json
import subprocess
import uuid

ROOT=Path(__file__).resolve().parent
BENCH=ROOT
spec=importlib.util.spec_from_file_location('matrix',BENCH/'run_matrix.py')
previous=importlib.util.module_from_spec(spec);spec.loader.exec_module(previous)
DOCKER=previous.DOCKER
run=ROOT/'build'/('combination_matrix_'+uuid.uuid4().hex[:10]);run.mkdir()
manifest={'status':'running','cases':[],'order':['A','B','B','A'],'samples_per_operation_per_block':10,'warmups':2,'scope':'Small ACL, one user, every retained context has a distinct role set (N=K); user GRANT/REVOKE invalidates all combinations.'}
audit=run/'container_isolation.jsonl'
try:
    for users,combinations in ((1,32),(1,256),(1,1024),(1,4096)):
        for block,variant in enumerate(manifest['order']):
            key=f'u{users}_r{combinations}_{block}_{variant}';output=run/key;output.mkdir()
            name='pr117270-combo-'+run.name[-10:]+'-'+key.lower()
            command=[DOCKER,'run','--rm','--name',name,'--platform','linux/arm64','--network','none','--hostname','pr117270-bench','--add-host','pr117270-bench:127.0.0.1','--memory','6g','--memory-swap','6g','--cpus','4','--cpuset-cpus','0-3','--mount',f'type=bind,src={BENCH/"bin"},dst=/inputs,readonly','--mount',f'type=bind,src={BENCH},dst=/bench,readonly','--mount',f'type=bind,src={ROOT},dst=/scripts,readonly','--mount',f'type=bind,src={output},dst=/out','--entrypoint','python3',previous.IMAGE,'/scripts/stress_combinations.py','--variant',variant,'--combinations',str(combinations),'--block',str(block)]
            previous.check_container_isolation(name,audit)
            print('COMBINATION_START',key,flush=True)
            with (output/'test.log').open('w') as log:
                proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
                try:
                    while True:
                        try:code=proc.wait(timeout=5);break
                        except subprocess.TimeoutExpired:previous.check_container_isolation(name,audit)
                    assert code==0,(key,code)
                    previous.check_container_isolation(name,audit)
                except BaseException:
                    subprocess.run([DOCKER,'stop','--time','5',name],stdout=log,stderr=subprocess.STDOUT);proc.wait();raise
            result=json.loads((output/'result.json').read_text());assert result['status']=='passed'
            manifest['cases'].append({'path':str(output.relative_to(ROOT)),**result})
            (run/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
            print('COMBINATION_CASE_PASS',key,flush=True)
    manifest['status']='passed'
    print('COMBINATION_MATRIX_PASS',run,flush=True)
except BaseException as error:
    manifest.update(status='failed',error=repr(error));raise
finally:
    (run/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (ROOT/'latest_combination_matrix.json').write_text(json.dumps({'path':str(run),'status':manifest['status']},indent=2)+'\n')
