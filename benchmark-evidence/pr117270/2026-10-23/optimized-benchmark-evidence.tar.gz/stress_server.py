import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import math
from pathlib import Path
import statistics
import threading
import time
from server_support import Fixture

p=argparse.ArgumentParser()
p.add_argument('--variant',choices=['A','B'],required=True)
p.add_argument('--users',type=int,required=True)
p.add_argument('--combinations',type=int,default=32)
p.add_argument('--rounds',type=int,default=2048)
p.add_argument('--readers',type=int,default=4)
p.add_argument('--block',type=int,required=True)
args=p.parse_args()
assert args.combinations in (16,32)
out=Path('/out')
result={'status':'running','variant':args.variant,'users':args.users,'combinations':args.combinations,'rounds':args.rounds,'readers':args.readers,'block':args.block}
def stats(values):
    values=sorted(values)
    def q(v):return values[math.ceil(len(values)*v)-1]
    return {'samples':len(values),'p50_ms':statistics.median(values),'p95_ms':q(.95),'p99_ms':q(.99),'max_ms':max(values)}
try:
    with Fixture(args.variant) as f:
        result['source_sha']=f.options['GIT_HASH']
        result['isolation_id']=f.identity
        a=f.admin
        a.query('CREATE DATABASE pressure_data')
        a.query('CREATE TABLE pressure_data.seed (x UInt8) ENGINE=Memory')
        role_count=int(math.log2(args.combinations))
        roles=[f'pressure_role_{i}' for i in range(role_count)]
        for role in roles:
            a.query(f'CREATE ROLE {role}')
            a.query(f'GRANT SELECT ON pressure_data.seed TO {role}')
        for i in range(args.rounds):a.query(f'CREATE DATABASE pressure_db_{i}')
        population_start=time.monotonic()
        for user_index in range(args.users):
            user=f'pressure_population_{user_index}'
            a.query(f'CREATE USER {user} IDENTIFIED WITH no_password SETTINGS log_queries=0')
            a.query(f'GRANT {",".join(roles)} TO {user}')
            a.query(f'SET DEFAULT ROLE NONE TO {user}')
            c=f.client(user,f'{f.identity}_load_{user_index}')
            c.query('SELECT 1')
            for mask in range(1,args.combinations):
                chosen=','.join(role for i,role in enumerate(roles) if mask&(1<<i))
                c.query('SET ROLE '+chosen,session_check=True)
                c.query('SELECT 1',session_check=True)
            c.close()
            if user_index%128==0:print('POPULATION_PROGRESS',user_index,flush=True)
        result['population_warmup_seconds']=time.monotonic()-population_start
        result['population_users_verified']=int(a.query("SELECT count() FROM system.users WHERE startsWith(name,'pressure_population_')")[0])
        assert result['population_users_verified']==args.users
        probes=[]
        for index in range(args.readers):
            user=f'pressure_probe_{index}'
            a.query(f'CREATE USER {user} IDENTIFIED WITH no_password SETTINGS log_queries=0')
            c=f.client(user,f'{f.identity}_probe_{index}')
            c.query('SELECT 1')
            probes.append(c)
        a.query('CREATE USER pressure_writer IDENTIFIED WITH no_password SETTINGS log_queries=0')
        anchor=f.client('pressure_writer',f.identity+'_writer_anchor')
        anchor.query('SELECT 1')
        writer=f.client()
        def global_calculations():
            found=a.rows("SELECT value FROM system.events WHERE event='EffectiveAccessRightsCalculations'")
            return int(found[0]['value']) if found else 0
        result['global_calculations_before']=global_calculations()
        barrier=threading.Barrier(args.readers+1)
        started=time.perf_counter_ns()
        def run_worker(index):
            samples=[]
            try:
                for iteration in range(args.rounds):
                    barrier.wait(timeout=60)
                    begin=time.perf_counter_ns()
                    if index==args.readers:
                        operation='GRANT' if iteration%2==0 else 'REVOKE'
                        direction='TO' if operation=='GRANT' else 'FROM'
                        qid=f.identity+f'_writer_{iteration}'
                        writer.query(f'{operation} SELECT ON pressure_data.target {direction} pressure_writer',query_id=qid)
                        sample={'kind':'writer','operation':operation,'query_id':qid}
                    else:
                        c=probes[index]
                        c.database=f'pressure_db_{iteration}'
                        answer,_=c.query('SELECT 1',session_check=True)
                        assert answer=='1'
                        sample={'kind':'reader','reader':index}
                    finish=time.perf_counter_ns()
                    samples.append(dict(sample,iteration=iteration,begin_ns=begin-started,end_ns=finish-started,wall_ms=(finish-begin)/1e6))
                return samples
            except BaseException:
                barrier.abort()
                raise
        with ThreadPoolExecutor(max_workers=args.readers+1) as pool:
            futures=[pool.submit(run_worker,index) for index in range(args.readers+1)]
            groups=[future.result() for future in futures]
        result['pressure_seconds']=(time.perf_counter_ns()-started)/1e9
        result['population_age_at_finish_seconds']=time.monotonic()-population_start
        assert result['population_age_at_finish_seconds']<550,'Population contexts may have expired'
        result['global_calculations_after']=global_calculations()
        result['global_calculation_delta']=result['global_calculations_after']-result['global_calculations_before']
        if args.variant=='B':assert result['global_calculation_delta']==args.rounds,result['global_calculation_delta']
        records=[sample for group in groups for sample in group]
        with (out/'samples.jsonl').open('w') as raw:
            for sample in records:raw.write(json.dumps(sample)+'\n')
        result['reader_summary']=stats([s['wall_ms'] for s in records if s['kind']=='reader'])
        result['writer_summary']=stats([s['wall_ms'] for s in records if s['kind']=='writer'])
        a.query('SYSTEM FLUSH LOGS')
        query_log=a.rows("SELECT query_id,toString(type) AS type,query_duration_ms,ProfileEvents['EffectiveAccessRightsCalculations'] AS calculations,ProfileEvents['EffectiveAccessRightsCacheHits'] AS cache_hits FROM system.query_log WHERE startsWith(query_id,'"+f.identity+"_writer_') AND type!='QueryStart'")
        assert len(query_log)==args.rounds and all(row['type']=='QueryFinish' for row in query_log)
        (out/'writer_query_log.json').write_text(json.dumps(query_log,indent=2)+'\n')
        result['writer_query_finish_count']=len(query_log)
        assert anchor.query('CHECK GRANT SELECT ON pressure_data.target',session_check=True)[0]=='0'
        result['status']='passed'
        print('SERVER_PRESSURE_PASS',json.dumps({k:result[k] for k in ('variant','users','combinations','reader_summary','writer_summary','global_calculation_delta')}),flush=True)
except BaseException as error:
    result.update(status='failed',error=repr(error))
    raise
finally:
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
