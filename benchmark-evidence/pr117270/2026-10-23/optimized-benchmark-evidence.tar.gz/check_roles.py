import json
from pathlib import Path
import uuid
from server_support import Fixture

out=Path('/out')
result={'status':'running','test':'live_role_permission_updates','cases':[]}
try:
    with Fixture() as f:
        result['source_sha']=f.options['GIT_HASH']
        result['isolation_id']=f.identity
        a=f.admin
        a.query('CREATE DATABASE role_data')
        a.query('CREATE TABLE role_data.seed (x UInt8) ENGINE=Memory')
        a.query('CREATE TABLE role_data.target (x UInt8) ENGINE=Memory')
        a.query('CREATE TABLE role_data.other (x UInt8) ENGINE=Memory')
        def validate(client,allowed):
            assert client.query('CHECK GRANT SELECT ON role_data.target',session_check=True)[0]==str(int(allowed))
            assert client.query('CHECK GRANT INSERT ON role_data.target',session_check=True)[0]=='0'
            if allowed:
                assert client.query('SELECT count() FROM role_data.target',session_check=True)[0]=='0'
            else:
                try:client.query('SELECT count() FROM role_data.target',session_check=True)
                except RuntimeError as error:assert 'ACCESS_DENIED' in str(error),str(error)
                else:raise AssertionError('Revoked/absent SELECT remained executable')
        for n in (1,10,50):
            user=f'role_user_{n}'
            role=f'role_shared_{n}'
            a.query(f'CREATE USER {user} IDENTIFIED WITH no_password')
            a.query(f'CREATE ROLE {role}')
            a.query(f'GRANT SELECT ON role_data.seed TO {role}')
            a.query(f'GRANT {role} TO {user}')
            a.query(f'SET DEFAULT ROLE {role} TO {user}')
            before=a.query(f'SHOW CREATE USER {user}')[0]
            clients=[]
            for i in range(n):
                db=f'role_session_{n}_{i}'
                a.query(f'CREATE DATABASE {db}')
                c=f.client(user,f'{f.identity}_{n}_{i}',db)
                c.query('SELECT 1')
                assert c.query('SELECT currentRoles() FORMAT TSVRaw',session_check=True)[0]==f"['{role}']"
                c.query('SELECT count() FROM role_data.seed',session_check=True)
                validate(c,False)
                clients.append(c)
            case={'sessions':n,'updates':[]}
            for iteration in range(3):
                for op,allowed in (('GRANT',True),('REVOKE',False)):
                    direction='TO' if allowed else 'FROM'
                    qid=f.identity+f'_role_{n}_{op}_{iteration}'
                    _,seconds=a.query(f'{op} SELECT ON role_data.target {direction} {role}',query_id=qid)
                    for c in clients:validate(c,allowed)
                    assert a.query(f'SHOW CREATE USER {user}')[0]==before
                    events=f.events(qid)
                    assert int(events['calculations'])==1 and int(events['cache_hits'])>=n-1,events
                    case['updates'].append({'operation':op,'iteration':iteration,'seconds':seconds,'existing_sessions_checked':n,'user_definition_unchanged':True,'events':events})
            result['cases'].append(case)
            print('LIVE_ROLE_CASE_PASS',n,flush=True)
        a.query('CREATE ROLE role_mix_a')
        a.query('CREATE ROLE role_mix_b')
        a.query('GRANT SELECT ON role_data.seed TO role_mix_a')
        a.query('GRANT SELECT ON role_data.other TO role_mix_b')
        a.query('CREATE USER role_mix_user IDENTIFIED WITH no_password')
        a.query('GRANT role_mix_a,role_mix_b TO role_mix_user')
        a.query('SET DEFAULT ROLE role_mix_a TO role_mix_user')
        before=a.query('SHOW CREATE USER role_mix_user')[0]
        mixes=[]
        for index,roles in enumerate([('role_mix_a',),('role_mix_b',),('role_mix_a','role_mix_b')]*2):
            db=f'role_mix_db_{index}'
            a.query(f'CREATE DATABASE {db}')
            c=f.client('role_mix_user',f'{f.identity}_mix_{index}',db)
            c.query('SET ROLE '+','.join(roles))
            validate(c,False)
            mixes.append((c,'role_mix_a' in roles))
        mixed={'sessions':6,'role_sets':3,'updates':[]}
        for iteration in range(3):
            for op,allowed in (('GRANT',True),('REVOKE',False)):
                qid=f.identity+f'_mixed_{op}_{iteration}'
                a.query(f"{op} SELECT ON role_data.target {'TO' if allowed else 'FROM'} role_mix_a",query_id=qid)
                for c,has_a in mixes:validate(c,allowed and has_a)
                assert a.query('SHOW CREATE USER role_mix_user')[0]==before
                events=f.events(qid)
                assert 1<=int(events['calculations'])<=3 and int(events['cache_hits'])>=1,events
                mixed['updates'].append({'operation':op,'iteration':iteration,'existing_sessions_checked':6,'user_definition_unchanged':True,'events':events})
        result['mixed_role_sets']=mixed
        print('LIVE_MIXED_ROLE_SETS_PASS',flush=True)
    result['status']='passed'
    print('LIVE_ROLE_PERMISSION_UPDATES_PASS',flush=True)
except BaseException as error:
    result.update(status='failed',error=repr(error))
    raise
finally:
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
