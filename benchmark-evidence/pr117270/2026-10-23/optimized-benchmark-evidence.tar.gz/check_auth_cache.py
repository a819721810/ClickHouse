import http.client
import json
from pathlib import Path
import uuid
from server_support import Fixture,bench

class PasswordConnection(http.client.HTTPConnection):
    def __init__(self,password):
        super().__init__('127.0.0.1',8123,timeout=300)
        self.password=password
    def request(self,method,url,body=None,headers=None,**kwargs):
        headers=dict(headers or {});headers['X-ClickHouse-Key']=self.password
        return super().request(method,url,body=body,headers=headers,**kwargs)

out=Path('/out');result={'status':'running','test':'authentication_grants_cache_isolation','cases':[]}
try:
    with Fixture() as f:
        a=f.admin;result['source_sha']=f.options['GIT_HASH'];result['isolation_id']=f.identity
        a.query('CREATE DATABASE auth_data');a.query('CREATE DATABASE auth_alt')
        for table in ('one','two','three'):a.query(f'CREATE TABLE auth_data.{table} (x UInt8) ENGINE=Memory')
        a.query('CREATE USER auth_sink IDENTIFIED WITH no_password')
        def metrics():
            rows=a.rows("SELECT event,value FROM system.events WHERE event IN ('EffectiveAccessRightsCalculations','EffectiveAccessRightsCacheHits')")
            data={row['event']:int(row['value']) for row in rows}
            return {key:data.get(key,0) for key in ('EffectiveAccessRightsCalculations','EffectiveAccessRightsCacheHits')}
        def client(user,password,sid,db='default'):
            c=f.client(user,sid,db);c.connection=PasswordConnection(password);return c
        def denied(c,sql):
            try:c.query(sql,session_check=True)
            except RuntimeError as error:assert 'ACCESS_DENIED' in str(error)
            else:raise AssertionError('Limited or revoked credential executed forbidden SQL')
        for order in ('full_first','limited_first'):
            user='auth_'+order
            full_password=uuid.uuid4().hex;limited_password=uuid.uuid4().hex
            a.query(f"CREATE USER {user} IDENTIFIED WITH sha256_password BY '{full_password}', sha256_password BY '{limited_password}' GRANTS (SELECT ON auth_data.one)")
            a.query(f'GRANT SELECT ON auth_data.one, SELECT ON auth_data.two TO {user} WITH GRANT OPTION')
            full=client(user,full_password,f.identity+'_'+order+'_full')
            if order=='full_first':assert full.query('SELECT count() FROM auth_data.two')[0]=='0'
            before=metrics();limited=[]
            for index,db in enumerate(('default','auth_alt')):
                c=client(user,limited_password,f.identity+'_'+order+f'_limited_{index}',db)
                assert c.query('SELECT count() FROM auth_data.one')[0]=='0'
                denied(c,'SELECT count() FROM auth_data.two')
                denied(c,'GRANT SELECT ON auth_data.one TO auth_sink')
                limited.append(c)
            after=metrics()
            assert after['EffectiveAccessRightsCacheHits']==before['EffectiveAccessRightsCacheHits'],(before,after)
            assert after['EffectiveAccessRightsCalculations']>before['EffectiveAccessRightsCalculations']
            assert full.query('SELECT count() FROM auth_data.two')[0]=='0'
            full.query('GRANT SELECT ON auth_data.two TO auth_sink',session_check=True)
            a.query(f'GRANT SELECT ON auth_data.three TO {user}')
            assert full.query('SELECT count() FROM auth_data.three',session_check=True)[0]=='0'
            for c in limited:denied(c,'SELECT count() FROM auth_data.three')
            a.query(f'REVOKE SELECT ON auth_data.one FROM {user}')
            for c in [full]+limited:denied(c,'SELECT count() FROM auth_data.one')
            assert full.query('SELECT count() FROM auth_data.two',session_check=True)[0]=='0'
            result['cases'].append({'order':order,'limited_sessions':2,'limited_initial_calculation_delta':after['EffectiveAccessRightsCalculations']-before['EffectiveAccessRightsCalculations'],'limited_initial_cache_hit_delta':after['EffectiveAccessRightsCacheHits']-before['EffectiveAccessRightsCacheHits'],'restricted_reads_denied':True,'restricted_delegation_denied':True,'full_credential_not_poisoned':True,'existing_sessions_observe_revocation':True})
            print('AUTH_CACHE_CASE_PASS',order,flush=True)
        result['status']='passed';print('AUTHENTICATION_GRANTS_CACHE_ISOLATION_PASS',flush=True)
except BaseException as error:
    result.update(status='failed',error=repr(error));raise
finally:(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
