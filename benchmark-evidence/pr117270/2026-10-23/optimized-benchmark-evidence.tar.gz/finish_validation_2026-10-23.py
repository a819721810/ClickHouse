from pathlib import Path
from datetime import datetime, timezone
import json
import subprocess

ROOT = Path(__file__).resolve().parent
pipeline = json.loads((ROOT / 'pipeline.json').read_text())

def save():
    pipeline['updated_utc'] = datetime.now(timezone.utc).isoformat()
    (ROOT / 'pipeline.json').write_text(json.dumps(pipeline, indent=2) + '\n')

try:
    latest = json.loads((ROOT / 'latest_matrix.json').read_text())
    assert latest['status'] == 'passed' and not latest['pilot']
    manifest = json.loads((Path(latest['path']) / 'manifest.json').read_text())
    assert manifest['status'] == 'passed' and len(manifest['completed_runs']) == 24
    pipeline['recovery'] = 'Complete fresh large-ACL matrix after replacing ps/inspect with a single daemon snapshot; repeat combination and pressure suites to check earlier tail variation.'
    for phase, script in [('combinations_repeat','run_combination_matrix.py'), ('pressure_repeat','run_pressure_matrix.py'), ('report','make_report.py')]:
        pipeline.update(status='running', phase=phase);save()
        print('RECOVERY_START',phase,flush=True)
        with (ROOT / 'build' / ('test_' + phase + '_2026-10-23.log')).open('w') as log:
            subprocess.run(['python3',str(ROOT / script)],check=True,stdout=log,stderr=subprocess.STDOUT)
        print('RECOVERY_PASS',phase,flush=True)
    pipeline.pop('error',None)
    pipeline.update(status='passed',phase='complete');save()
except BaseException as error:
    pipeline.update(status='failed',error=repr(error));save()
    raise
