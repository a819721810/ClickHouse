#include <algorithm>
#include <atomic>
#include <barrier>
#include <chrono>
#include <memory>
#include <thread>
#include <fstream>
#include <stdexcept>
#include <string>
#include <Access/EffectiveAccessRightsCache.h>

namespace DB
{
struct User {};
struct EnabledRolesInfo {};
class AccessRights {};
}

// Compile the unchanged production cache methods. Payloads are opaque here;
// their contents are never read by the cache. The UUID and settings are real.
#include <Access/EffectiveAccessRightsCache.cpp>

namespace Micro
{
using Clock = std::chrono::steady_clock;
using Ns = std::chrono::nanoseconds;

struct Alive
{
    DB::UserPtr user = std::make_shared<DB::User>();
    std::shared_ptr<const DB::EnabledRolesInfo> roles = std::make_shared<DB::EnabledRolesInfo>();
    std::shared_ptr<const DB::AccessRights> access = std::make_shared<DB::AccessRights>();
    std::shared_ptr<const DB::AccessRights> implicit = std::make_shared<DB::AccessRights>();
};

DB::UUID id(size_t index)
{
    return DB::UUID{UInt128{index + 1}};
}

void store(DB::EffectiveAccessRightsCache & cache, size_t index, const Alive & value)
{
    cache.store(id(index), value.user, value.roles, {}, value.access, value.implicit);
}

void find(DB::EffectiveAccessRightsCache & cache, size_t index, const Alive & value)
{
    auto result = cache.find(id(index), value.user, value.roles, {});
    if (!result || result->access != value.access || result->access_with_implicit != value.implicit)
        throw std::runtime_error("Unexpected cache miss or wrong result");
}

double us(Clock::duration duration)
{
    return std::chrono::duration<double, std::micro>(duration).count();
}

double quantile(std::vector<double> values, double q)
{
    std::sort(values.begin(), values.end());
    return values[std::min(values.size() - 1, static_cast<size_t>(std::ceil(q * values.size()) - 1))];
}

void summary(std::ofstream & output, const std::string & kind, size_t users, size_t roles, size_t repeat, const std::vector<double> & values)
{
    output << kind << ',' << users << ',' << roles << ',' << repeat << ',' << values.size() << ','
           << quantile(values, .5) << ',' << quantile(values, .95) << ',' << quantile(values, .99) << ','
           << *std::max_element(values.begin(), values.end()) << '\n';
}

void run()
{
    std::ofstream output("/out/measurements.csv");
    output << "kind,users,roles_per_user,repeat,samples,p50_us,p95_us,p99_us,max_us\n";
    for (size_t repeat = 0; repeat < 3; ++repeat)
    {
        for (size_t combinations : {size_t{1}, size_t{16}, size_t{256}, size_t{4096}})
        {
            DB::EffectiveAccessRightsCache cache;
            std::vector<Alive> values(combinations);
            auto user = values.front().user;
            for (auto & value : values)
            {
                value.user = user;
                store(cache, 0, value);
            }
            std::vector<double> first, last;
            for (size_t i = 0; i < 2000; ++i)
            {
                auto start = Clock::now();
                find(cache, 0, values.front());
                first.push_back(us(Clock::now() - start));
                start = Clock::now();
                find(cache, 0, values.back());
                last.push_back(us(Clock::now() - start));
            }
            summary(output, "find_first", 1, combinations, repeat, first);
            summary(output, "find_last", 1, combinations, repeat, last);
        }
        for (auto [users, roles] : {std::pair{size_t{100}, size_t{1}}, {size_t{1000}, size_t{16}}, {size_t{10000}, size_t{16}}})
        {
            DB::EffectiveAccessRightsCache cache;
            std::vector<Alive> values(users * roles);
            size_t stores = 0;
            for (size_t user = 0; user < users; ++user)
            {
                auto shared_user = values[user * roles].user;
                for (size_t role = 0; role < roles; ++role)
                {
                    auto & value = values[user * roles + role];
                    value.user = shared_user;
                    store(cache, user, value);
                    ++stores;
                }
            }
            Alive writer;
            Alive victim;
            store(cache, users, writer);
            store(cache, users + 1, victim);
            stores += 2;
            std::barrier start(2);
            std::atomic<bool> done{false};
            std::vector<double> reader_times;
            std::thread reader([&]
            {
                start.arrive_and_wait();
                while (!done.load(std::memory_order_relaxed))
                {
                    auto begin = Clock::now();
                    find(cache, users + 1, victim);
                    reader_times.push_back(us(Clock::now() - begin));
                }
            });
            std::vector<double> ordinary, sweeps;
            start.arrive_and_wait();
            for (size_t round = 0; round < 20; ++round)
            {
                while (stores % 1024 != 1023)
                {
                    auto begin = Clock::now();
                    store(cache, users, writer);
                    ordinary.push_back(us(Clock::now() - begin));
                    ++stores;
                }
                auto begin = Clock::now();
                store(cache, users, writer);
                sweeps.push_back(us(Clock::now() - begin));
                ++stores;
            }
            done.store(true, std::memory_order_relaxed);
            reader.join();
            summary(output, "store_ordinary", users, roles, repeat, ordinary);
            summary(output, "store_global_sweep", users, roles, repeat, sweeps);
            summary(output, "unrelated_find_during_stores", users, roles, repeat, reader_times);
            output.flush();
            std::cout << "MICRO_CASE_PASS " << repeat << ' ' << users << ' ' << roles << '\n';
        }
    }
    std::cout << "CACHE_COMPONENT_MICROBENCH_PASS\n";
}
}
