from pathlib import Path
import hashlib
import json
import subprocess
import sys

sources={name:hashlib.sha256(Path('/repo',name).read_bytes()).hexdigest() for name in ('src/Access/EffectiveAccessRightsCache.h','src/Access/EffectiveAccessRightsCache.cpp','src/Access/ImplicitExpansionSettings.h','base/base/UUID.h')}
Path('/out/source_hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
flags='-std=c++20 -pthread -I/scripts/shims -I/repo/src -I/repo/base -I/deps/contrib/boost'
mode=sys.argv[1]
flags += ' -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer' if mode=='sanitized' else ' -O3'
code='Checks::run();' if mode=='sanitized' else 'Checks::run(); Micro::run();'
subprocess.run(['/repo/.claude/tools/cppexpr.sh','--plain','-c','clang++-22','-O',flags,'-g','#include "/scripts/cache_micro.h"\n#include "/scripts/cache_checks.h"',code],check=True)
print('OPTIMIZED_COMPONENT_PASS',mode)
