import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time
import uuid

spec = importlib.util.spec_from_file_location('bench', '/bench/run_case.py')
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)
out = Path('/out')
work = Path('/work')
work.mkdir()
identity = 'followup_' + uuid.uuid4().hex
(work/'config.xml').write_text(bench.config(identity))
result = {'status':'running','test':'original_05054','isolation_id':identity}
server = None
admin = None
with (out/'server_stdout.log').open('w') as server_log:
    try:
        server = subprocess.Popen(['/inputs/clickhouse-B','server','--config-file=/work/config.xml'],cwd=work,env=dict(os.environ,CLICKHOUSE_WATCHDOG_ENABLE='0'),stdout=server_log,stderr=subprocess.STDOUT)
        deadline=time.monotonic()+120
        while True:
            if server.poll() is not None: raise RuntimeError('Server startup failed')
            candidate=bench.Client()
            try:
                assert candidate.query("SELECT getMacro('benchmark_isolation')")[0]==identity
                admin=candidate
                break
            except (ConnectionError,OSError):
                candidate.close()
                if time.monotonic()>deadline: raise RuntimeError('Server startup timeout')
                time.sleep(0.1)
        options={r['name']:r['value'] for r in admin.rows('SELECT * FROM system.build_options')}
        assert options['GIT_HASH']=='3319c0bf1944237c0ed87eac0fb0affc61a7d609'
        result['source_sha']=options['GIT_HASH']
        admin.query('CREATE DATABASE test')
        (work/'client.xml').write_text('<config><database>test</database></config>')
        test=Path('/repo/tests/queries/0_stateless/05054_effective_access_rights_cache.sh')
        env=dict(os.environ,CLICKHOUSE_BINARY='/inputs/clickhouse-B',CLICKHOUSE_CLIENT='/inputs/clickhouse-B client --host 127.0.0.1 --port 9000 --config-file=/work/client.xml --no-warnings --no-secure --send_logs_level none',CLICKHOUSE_DATABASE='test',CLICKHOUSE_HOST='127.0.0.1',CLICKHOUSE_PORT_TCP='9000',CLICKHOUSE_PORT_HTTP='8123',CLICKHOUSE_CONFIG='/work/config.xml')
        with (out/'original.stdout').open('w') as stdout, (out/'original.stderr').open('w') as stderr:
            completed=subprocess.run(['bash',str(test)],env=env,stdout=stdout,stderr=stderr,timeout=180)
        result['exit_code']=completed.returncode
        result['test_sha256']=hashlib.sha256(test.read_bytes()).hexdigest()
        expected=test.with_suffix('.reference').read_text()
        actual=(out/'original.stdout').read_text()
        (out/'expected.stdout').write_text(expected)
        result['reference_matches']=actual==expected
        admin.query('SYSTEM FLUSH LOGS')
        result['grant_query_events']=admin.rows("SELECT query_id,toString(type) AS type,ProfileEvents['EffectiveAccessRightsCalculations'] AS calculations,ProfileEvents['EffectiveAccessRightsCacheHits'] AS cache_hits FROM system.query_log WHERE query_id IN ('05054_effective_access_rights_cache_test_earc_g','05054_effective_access_rights_cache_test_earc_g3') AND type != 'QueryStart' ORDER BY query_id")
        assert completed.returncode==0,completed.returncode
        assert actual==expected, {'expected':expected,'actual':actual}
        assert len(result['grant_query_events'])==2
        for row in result['grant_query_events']:
            assert row['type']=='QueryFinish' and int(row['cache_hits'])>=1,row
        assert not (out/'original.stderr').read_text().strip(),(out/'original.stderr').read_text()[:1000]
        result['status']='passed'
        print('ORIGINAL_05054_PASS',json.dumps(result['grant_query_events']),flush=True)
    except BaseException as error:
        result.update(status='failed',error=repr(error))
        raise
    finally:
        if admin: admin.close()
        if server and server.poll() is None:
            server.terminate()
            try: server.wait(timeout=30)
            except subprocess.TimeoutExpired:
                server.kill();server.wait();result['forced_shutdown']=True
        (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
