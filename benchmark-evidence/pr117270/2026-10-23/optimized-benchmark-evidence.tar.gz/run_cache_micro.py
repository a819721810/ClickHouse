from pathlib import Path
import json
import subprocess
import hashlib

sources={p:hashlib.sha256(Path('/repo',p).read_bytes()).hexdigest() for p in ('src/Access/EffectiveAccessRightsCache.h','src/Access/EffectiveAccessRightsCache.cpp','src/Access/ImplicitExpansionSettings.h','base/base/UUID.h')}
Path('/out/source_hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
command=['/repo/.claude/tools/cppexpr.sh','--plain','-c','clang++-22','-O','-std=c++20 -O3 -pthread -I/scripts/shims -I/repo/src -I/repo/base -I/deps/contrib/boost','-g','#include "/scripts/cache_micro.h"','Micro::run();']
subprocess.run(command,check=True)
