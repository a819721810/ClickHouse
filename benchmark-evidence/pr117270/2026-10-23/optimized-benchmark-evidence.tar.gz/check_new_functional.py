from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('original','/prior/check_original.py')
# Preserve the original runner's checks, replacing only the test selector and
# query-specific profile-event checks for this behavior-only regression.
s=Path('/prior/check_original.py').read_text()
s=s.replace('05054_effective_access_rights_cache.sh','05055_effective_access_rights_role_permissions.sh')
s=s.replace("result['grant_query_events']=admin.rows(","result['grant_query_events']=admin.rows(")
s=s.replace("assert len(result['grant_query_events'])==2", "assert len(result['grant_query_events'])==0")
s=s.replace("'original_05054'", "'new_role_regression'")
s=s.replace('ORIGINAL_05054_PASS','FORMAL_ROLE_REGRESSION_PASS')
exec(compile(s,'formal_role_regression_runner','exec'))
