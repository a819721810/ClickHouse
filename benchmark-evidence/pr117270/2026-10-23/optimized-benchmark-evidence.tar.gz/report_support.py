import re

def normalized_flags(text):
    # These options control concurrent linker work, not optimization level.
    text = re.sub(r"-Wl,--(?:thinlto-jobs|threads)=\d+", "", text)
    # The local backend cache reuses compiled modules without changing optimization.
    text = re.sub(r"-Wl,--thinlto-cache-dir=(?:(?:\./build|/build/build)/thinlto-cache|\.\./thinlto-cache)", "", text)
    # CI and this local build place the same compiler-rt archives in different
    # output directories. Only these two observed archive paths are normalized.
    text = re.sub(
        r"(?:\./(?:ci/tmp/build|build)|\.\.)/contrib/compiler-rt-cmake/(libclang_rt_(?:builtins|xray)\.a)",
        r"<BUILD>/contrib/compiler-rt-cmake/\1", text)
    return " ".join(text.split())

