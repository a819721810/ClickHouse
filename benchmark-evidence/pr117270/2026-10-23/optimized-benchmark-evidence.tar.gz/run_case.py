#!/usr/bin/env python3
"""Run one isolated ACL benchmark case inside a disposable Linux container.

Only synthetic principals and identifiers are used. No external network is needed.
The caller supplies a fixed binary and mounts a unique empty output directory.
"""
import argparse
import hashlib
import http.client
import json
import math
import os
from pathlib import Path
import subprocess
import time
import urllib.parse
import uuid

BASE_SHA = "dd7889a115c63e16f3bcbc9f843e4633fb2fe1e0"
PR_SHA = "3319c0bf1944237c0ed87eac0fb0affc61a7d609"
PATHS = 15580
ROWS = 75123
ROLE_PATHS = 465
ROLE_ROWS = 471
OWNER = "SELECT, INSERT, ALTER, TRUNCATE, OPTIMIZE"
DB = "bench_data"
USER = "bench_user"
ROLE = "bench_public_role"
OUT = Path("/out")
WORK = Path("/work")


class Client:
    def __init__(self, user="default", session=None, database="default"):
        self.user, self.session, self.database = user, session, database
        self.connection = http.client.HTTPConnection("127.0.0.1", 8123, timeout=300)

    def query(self, sql, query_id=None, session_check=False):
        parameters = {"database": self.database}
        if query_id:
            parameters["query_id"] = query_id
        if self.session:
            parameters.update(session_id=self.session, session_timeout=3600)
            if session_check:
                parameters["session_check"] = 1
        url = "/?" + urllib.parse.urlencode(parameters)
        start = time.perf_counter_ns()
        self.connection.request("POST", url, body=sql.encode(), headers={
            "X-ClickHouse-User": self.user,
            "Content-Type": "text/plain; charset=utf-8",
        })
        response = self.connection.getresponse()
        body = response.read().decode()
        elapsed = (time.perf_counter_ns() - start) / 1e9
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}: {body[:2000]}")
        return body.strip(), elapsed

    def rows(self, sql):
        body, _ = self.query(sql + " FORMAT JSONEachRow")
        return [json.loads(line) for line in body.splitlines() if line]

    def close(self):
        self.connection.close()


def count_grants(client, subject, role=False):
    key = "role_name" if role else "user_name"
    return client.rows(
        "SELECT count() AS privilege_rows, uniqExact(tuple(database, table)) AS table_paths, "
        "countIf(is_partial_revoke) AS partial_revokes, countIf(column != '') AS column_rows "
        f"FROM system.grants WHERE {key} = '{subject}'"
    )[0]


def seed(client):
    client.query(f"CREATE DATABASE {DB}")
    client.query(f"CREATE USER {USER} IDENTIFIED WITH no_password SETTINGS log_queries = 0")
    client.query(f"CREATE ROLE {ROLE}")
    client.query("CREATE USER bench_probe IDENTIFIED WITH no_password")
    client.query(f"GRANT {OWNER} ON {DB}.probe TO bench_probe")
    leaves = [row["access_type"] for row in client.rows(
        "SELECT toString(access_type) AS access_type FROM system.grants "
        "WHERE user_name = 'bench_probe' ORDER BY access_type"
    )]
    assert "SELECT" in leaves and len(leaves) > 1, leaves
    extra = [x for x in leaves if x != "SELECT"]
    owners, remainder = divmod(ROWS - PATHS, len(extra))
    assert owners + bool(remainder) <= PATHS
    client.query("DROP USER bench_probe")

    statements = []
    for begin in range(0, PATHS, 1000):
        elements = []
        for i in range(begin, min(begin + 1000, PATHS)):
            privileges = OWNER if i < owners else "SELECT"
            if i == owners and remainder:
                privileges += ", " + ", ".join(extra[:remainder])
            elements.append(f"{privileges} ON {DB}.F{i:06d}")
        statements.append("GRANT " + ", ".join(elements) + f" TO {USER}")

    # Spread role paths over the direct-grant paths rather than clustering them
    # at the beginning of the table-name order. Each role grant remains read-only.
    elements = []
    for i in range(ROLE_PATHS):
        table = i * PATHS // ROLE_PATHS
        privileges = "SELECT, SHOW COLUMNS" if i < ROLE_ROWS - ROLE_PATHS else "SELECT"
        elements.append(f"{privileges} ON {DB}.F{table:06d}")
    statements.append("GRANT " + ", ".join(elements) + f" TO {ROLE}")
    statements.append(f"GRANT {ROLE} TO {USER}")
    statements.append(f"SET DEFAULT ROLE {ROLE} TO {USER}")
    for statement in statements:
        client.query(statement)

    user_counts = count_grants(client, USER)
    role_counts = count_grants(client, ROLE, role=True)
    expected_user = {"privilege_rows": ROWS, "table_paths": PATHS, "partial_revokes": 0, "column_rows": 0}
    expected_role = {"privilege_rows": ROLE_ROWS, "table_paths": ROLE_PATHS, "partial_revokes": 0, "column_rows": 0}
    assert {k: int(v) for k, v in user_counts.items()} == expected_user, user_counts
    assert {k: int(v) for k, v in role_counts.items()} == expected_role, role_counts
    fixture = "\n".join(statements)
    (OUT / "fixture.sql").write_text(fixture + "\n")
    result = {"historical_snapshot": "2026-09-18 aggregate ACL snapshot",
              "representation": "Synthetic ACL matching aggregate counts; not an exact production ACL dump",
              "user": user_counts, "role": role_counts, "owner_paths": owners,
              "partially_filled_owner_paths": int(bool(remainder)),
              "owner_expanded_privilege_count": len(leaves),
              "role_overlap": "465 deterministic paths distributed over the 15580 direct-grant paths",
              "fixture_sha256": hashlib.sha256(fixture.encode()).hexdigest()}
    (OUT / "dataset.json").write_text(json.dumps(result, indent=2))
    return result


def config(isolation_id):
    return f"""<clickhouse>
<logger><level>warning</level><log>/out/server.log</log><errorlog>/out/server_error.log</errorlog><console>0</console></logger>
<path>/work/data/</path><tmp_path>/work/tmp/</tmp_path><user_files_path>/work/user_files/</user_files_path>
<listen_host>127.0.0.1</listen_host><http_port>8123</http_port><tcp_port>9000</tcp_port>
<max_server_memory_usage>5368709120</max_server_memory_usage><max_thread_pool_size>128</max_thread_pool_size>
<background_pool_size>4</background_pool_size><background_schedule_pool_size>4</background_schedule_pool_size>
<background_message_broker_schedule_pool_size>2</background_message_broker_schedule_pool_size>
<background_distributed_schedule_pool_size>2</background_distributed_schedule_pool_size>
<background_buffer_flush_schedule_pool_size>2</background_buffer_flush_schedule_pool_size>
<background_move_pool_size>2</background_move_pool_size><background_fetches_pool_size>2</background_fetches_pool_size>
<background_common_pool_size>2</background_common_pool_size>
<mark_cache_size>16777216</mark_cache_size><uncompressed_cache_size>16777216</uncompressed_cache_size>
<merge_tree><number_of_free_entries_in_pool_to_execute_mutation>0</number_of_free_entries_in_pool_to_execute_mutation>
<number_of_free_entries_in_pool_to_lower_max_size_of_merge>0</number_of_free_entries_in_pool_to_lower_max_size_of_merge>
<number_of_free_entries_in_pool_to_execute_optimize_entire_partition>0</number_of_free_entries_in_pool_to_execute_optimize_entire_partition></merge_tree>
<profiles><default><max_threads>2</max_threads><max_memory_usage>4294967296</max_memory_usage>
<max_query_size>8388608</max_query_size><max_ast_elements>1000000</max_ast_elements>
<max_expanded_ast_elements>1000000</max_expanded_ast_elements><max_execution_time>300</max_execution_time>
<log_queries>1</log_queries><log_profile_events>1</log_profile_events>
<query_profiler_cpu_time_period_ns>0</query_profiler_cpu_time_period_ns>
<query_profiler_real_time_period_ns>0</query_profiler_real_time_period_ns></default></profiles>
<users><default><password></password><networks><ip>127.0.0.1</ip></networks><profile>default</profile><quota>default</quota><access_management>1</access_management></default></users>
<quotas><default/></quotas><user_directories><users_xml><path>/work/config.xml</path></users_xml>
<local_directory><path>/work/access/</path></local_directory></user_directories>
<macros><benchmark_isolation>{isolation_id}</benchmark_isolation></macros>
<max_session_timeout>3600</max_session_timeout><default_session_timeout>3600</default_session_timeout>
<query_log><database>system</database><table>query_log</table><flush_interval_milliseconds>1000</flush_interval_milliseconds></query_log>
</clickhouse>"""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", required=True)
    parser.add_argument("--variant", choices=("A", "B"), required=True)
    parser.add_argument("--sessions", type=int, choices=(1, 10, 50), required=True)
    parser.add_argument("--mode", choices=("shared", "distinct"), required=True)
    parser.add_argument("--samples", type=int, default=10)
    parser.add_argument("--warmups", type=int, default=2)
    parser.add_argument("--block", type=int, required=True)
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    WORK.mkdir(exist_ok=True)
    identity = "pr117270_" + uuid.uuid4().hex
    (WORK / "config.xml").write_text(config(identity))
    result = {"status": "running", "variant": args.variant, "sessions": args.sessions,
              "context_mode": args.mode, "block": args.block, "warmups": args.warmups,
              "samples_per_operation": args.samples, "measurements": [], "isolation_id": identity,
              "harness_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    proc = None
    admin = None
    sessions = []
    stdout = open(OUT / "server_stdout.log", "wb")
    try:
        # The caller supplies the already-unpacked A artifact or the ordinary B
        # executable. Keep both read-only; do not copy gigabytes into the test
        # data filesystem immediately before measuring metadata writes.
        binary = Path(args.binary)
        assert binary.is_file()
        env = dict(os.environ, CLICKHOUSE_WATCHDOG_ENABLE="0")
        proc = subprocess.Popen([str(binary), "server", "--config-file=/work/config.xml"],
                                stdout=stdout, stderr=subprocess.STDOUT, cwd=WORK, env=env)
        deadline = time.monotonic() + 120
        while True:
            if proc.poll() is not None:
                raise RuntimeError(f"Server exited at startup: {proc.returncode}")
            try:
                candidate = Client()
                actual, _ = candidate.query("SELECT getMacro('benchmark_isolation')")
                assert actual == identity
                admin = candidate
                break
            except (ConnectionError, OSError):
                candidate.close()
                if time.monotonic() >= deadline:
                    raise RuntimeError("Server startup timed out")
                time.sleep(0.2)
        options = {row["name"]: row["value"] for row in admin.rows("SELECT * FROM system.build_options")}
        result["build_options"] = options
        expected = BASE_SHA if args.variant == "A" else PR_SHA
        # `GIT_HASH` is generated by CMake from the checkout's `git rev-parse HEAD`.
        # `VERSION_GITHASH` is a release marker in `autogenerated_versions.txt`.
        assert options["GIT_HASH"] == expected, options.get("GIT_HASH")
        result["source_sha"] = options["GIT_HASH"]
        assert options["SYSTEM_PROCESSOR"] == "aarch64"
        result["version"] = admin.query("SELECT version()")[0]
        result["build_id"] = admin.query("SELECT buildId()")[0]
        result["dataset"] = seed(admin)
        print("DATASET_READY", json.dumps(result["dataset"]), flush=True)

        for i in range(args.sessions):
            database = "default"
            if args.mode == "distinct":
                database = f"bench_session_{i:02d}"
                admin.query(f"CREATE DATABASE {database}")
            client = Client(USER, identity + f"_session_{i}", database)
            client.query("SELECT 1")
            roles = client.query("SELECT currentRoles() FORMAT TSVRaw", session_check=True)[0]
            assert roles == "['bench_public_role']", roles
            sessions.append(client)
        result["session_roles"] = ROLE
        result["session_ids"] = [client.session for client in sessions]
        result["default_databases"] = [client.database for client in sessions]

        def validate(expected):
            for client in sessions:
                answer = client.query(f"CHECK GRANT SELECT ON {DB}.toggle", session_check=True)[0]
                assert answer == str(expected), (client.session, expected, answer)
                # A read-only role must not acquire a write privilege by sharing.
                denied = client.query(f"CHECK GRANT INSERT ON {DB}.unrelated", session_check=True)[0]
                assert denied == "0", denied

        validate(0)
        raw_path = OUT / "samples.jsonl"
        with raw_path.open("w") as raw:
            for iteration in range(args.warmups + args.samples):
                warmup = iteration < args.warmups
                for operation, expected in (("GRANT", 1), ("REVOKE", 0)):
                    qid = identity + f"_{operation.lower()}_{iteration}"
                    direction = "TO" if operation == "GRANT" else "FROM"
                    sql = f"{operation} SELECT ON {DB}.toggle {direction} {USER}"
                    _, elapsed = admin.query(sql, query_id=qid)
                    validate(expected)
                    record = {"query_id": qid, "operation": operation, "iteration": iteration,
                              "warmup": warmup, "client_seconds": elapsed,
                              "existing_session_checks_passed": len(sessions)}
                    result["measurements"].append(record)
                    raw.write(json.dumps(record) + "\n")
                    raw.flush()
                    print("SAMPLE", operation, iteration, round(elapsed, 6), "warmup" if warmup else "measured", flush=True)

        admin.query("SYSTEM FLUSH LOGS")
        logs = admin.rows(
            "SELECT query_id, toString(type) AS type, query_duration_ms, memory_usage, "
            "ProfileEvents['UserTimeMicroseconds'] AS user_cpu_us, "
            "ProfileEvents['SystemTimeMicroseconds'] AS system_cpu_us, "
            "ProfileEvents['OSCPUWaitMicroseconds'] AS cpu_wait_us, "
            "ProfileEvents['RealTimeMicroseconds'] AS thread_real_us, "
            "ProfileEvents['EffectiveAccessRightsCalculations'] AS calculations, "
            "ProfileEvents['EffectiveAccessRightsCacheHits'] AS cache_hits "
            f"FROM system.query_log WHERE startsWith(query_id, '{identity}_') AND type != 'QueryStart'"
        )
        log_map = {entry["query_id"]: entry for entry in logs}
        assert len(log_map) == len(result["measurements"]), (len(log_map), len(result["measurements"]))
        for record in result["measurements"]:
            server = log_map[record["query_id"]]
            assert server["type"] == "QueryFinish", server
            record["server"] = server
            if args.variant == "B":
                assert int(server["calculations"]) == 1, server
                if args.mode == "distinct" and args.sessions > 1:
                    assert int(server["cache_hits"]) >= args.sessions - 1, server
        counts = count_grants(admin, USER)
        assert int(counts["privilege_rows"]) == ROWS and int(counts["table_paths"]) == PATHS, counts
        result["final_user_counts"] = counts
        result["rss_snapshot"] = admin.rows("SELECT metric,value FROM system.asynchronous_metrics WHERE metric IN ('MemoryResident','MemoryVirtual')")
        result["status"] = "passed"
    except Exception as error:
        result.update(status="failed", error=repr(error))
        raise
    finally:
        for client in sessions:
            client.close()
        if admin:
            admin.close()
        if proc and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=30)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
                result["server_forced_shutdown"] = True
        stdout.close()
        (OUT / "result.json").write_text(json.dumps(result, indent=2))
        print("CASE_RESULT", result["status"], args.variant, args.sessions, args.mode,
              "completed_operations", len(result["measurements"]), flush=True)


if __name__ == "__main__":
    main()
