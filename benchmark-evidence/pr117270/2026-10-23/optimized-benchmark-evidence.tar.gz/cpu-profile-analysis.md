# CPU diagnostic, 2026-10-23

This is a separate diagnostic of the 4096-role-combination, zero-reuse workload. It is not part of the primary A/B timing matrix. Each variant has 24 completed updates, including four warm-up updates. A is `dd7889a115c63e16f3bcbc9f843e4633fb2fe1e0`; optimized B is `3319c0bf1944237c0ed87eac0fb0affc61a7d609`. Both run with four vCPUs and 6 GiB, with unrelated containers paused.

## Sampling interpretation

The configuration requests 100,000 ns (100 microseconds). However, `Timer::set` in `src/Common/QueryProfiler.cpp:196–199` clamps the timer period to at least 1,000,000 ns (1 millisecond, maximum 1000 signals/second per timer). That source file is identical in A and B. The raw manifests preserve the requested configuration; they do not establish a 10 kHz effective sampling rate. Do not convert sample counts using 100 microseconds.

Only CPU and Real traces are analyzed below. Memory and MemoryPeak records are kept separately. The sampling handler itself accounts for about 3% of CPU leaf samples; diagnostic timings must not be used to calculate a performance speedup.

## Observations

Inclusive percentages count a stack if it contains the named function or class. The groups overlap and must not be added.

| Variant | CPU / Real samples | Visible cache CPU / Real | Implicit expansion CPU | Access-rights destruction CPU |
|---|---:|---:|---:|---:|
| A | 1966 / 2003 | 0.00% / 0.00% | 57.73% | 25.43% |
| B | 2047 / 2057 | 0.68% / 0.49% | 58.67% | 24.33% |

The common call chain is `InterpreterGrantQuery` → `AccessControl::updateImpl` → `AccessChangesNotifier::sendNotifications` → `ContextAccess::setUser` → `ContextAccess::calculateAccessRights`, followed by implicit permission expansion and permission-tree release. CPU and Real distributions are similar, and query CPU nearly equals wall time in this diagnostic. This supports a CPU-dominated workload here; it does not explain the adverse concurrent-reader P99 block in the separate pressure suite.

The optimized variant has 14 visible cache CPU samples out of 2047 (0.68%) and 10 Real samples out of 2057 (0.49%). These include container frames whose symbols name `EffectiveAccessRightsCache`. Inlining, shared-pointer operations and lifecycle costs may be attributed to outer functions, so these percentages are not an upper bound on total cache cost. The sample count is insufficient to assign the remaining 5–7% matrix overhead to a particular cache operation.

Permission-tree construction and release dominate absolute CPU. In B, `getAllGrantableFlags` is the largest leaf (221/2047, 10.80%); `AccessRights` destruction appears in 24.33% of CPU stacks. The full collapsed stacks, rather than only the top stacks, support these observations. A has a similar hotspot distribution. These findings suggest investigating permission-tree construction and reuse in a separate change; they do not establish a specific next optimization or a promised gain.

## Evidence and reproduction

Run `python3 run_profiles.py > build/test_profiles_rerun.log 2>&1` and then `python3 analyze_profiles.py > build/test_profile_analysis_rerun.log 2>&1`. Each profiling run creates fresh outputs and updates `latest_profiles.json`. Inspect each log before accepting it.

The accepted directory is `build/profiles_b46979d94d`. It contains the two `result.json` files with source identity, query IDs and counters; `profile_summary.json`; complete `profile_CPU.collapsed` and `profile_Real.collapsed`; container isolation audits; and per-case test logs. `cpu-profile-analysis.json` recomputes sample totals and selected inclusive groups from the collapsed files. Six additional isolation audits passed; these are kept separate from the 213 primary benchmark/functional audits.

Conclusion: the previous quadratic cache-maintenance path has been removed, and same-role reuse retains its large benefit. The current evidence still includes 5–7% median overhead in the zero-reuse repeat and an adverse pressure-tail block. Profiling does not justify describing either as fully resolved.
