import argparse
import json
import math
from pathlib import Path
import statistics
import time
from server_support import Fixture

p=argparse.ArgumentParser();p.add_argument('--variant',required=True,choices=['A','B']);p.add_argument('--combinations',type=int,required=True);p.add_argument('--block',type=int,required=True);args=p.parse_args()
out=Path('/out');result={'status':'running','variant':args.variant,'combinations_seeded':args.combinations,'block':args.block,'samples_per_operation':10,'warmups_per_operation':2,'measurements':[]}
try:
    with Fixture(args.variant) as f:
        result['source_sha']=f.options['GIT_HASH'];result['isolation_id']=f.identity;a=f.admin
        a.query('CREATE DATABASE combo_data')
        role_count=int(math.log2(args.combinations));assert 2**role_count==args.combinations
        roles=[f'combo_role_{i}' for i in range(role_count)]
        for role in roles:
            a.query(f'CREATE ROLE {role}');a.query(f'GRANT SELECT ON combo_data.seed TO {role}')
        a.query('CREATE USER combo_user IDENTIFIED WITH no_password SETTINGS log_queries=0')
        a.query(f'GRANT {",".join(roles)} TO combo_user');a.query('SET DEFAULT ROLE NONE TO combo_user')
        c=f.client('combo_user',f.identity+'_combo_session');start=time.monotonic();c.query('SELECT 1')
        for mask in range(1,args.combinations):
            selected=','.join(role for i,role in enumerate(roles) if mask&(1<<i))
            c.query('SET ROLE '+selected,session_check=True);c.query('SELECT 1',session_check=True)
        result['population_warmup_seconds']=time.monotonic()-start
        print('COMBO_POPULATION_READY',args.variant,args.combinations,result['population_warmup_seconds'],flush=True)
        for iteration in range(12):
            for operation,expected in (('GRANT',1),('REVOKE',0)):
                qid=f.identity+f'_combo_{operation}_{iteration}'
                direction='TO' if expected else 'FROM'
                _,elapsed=a.query(f'{operation} SELECT ON combo_data.target {direction} combo_user',query_id=qid)
                assert c.query('CHECK GRANT SELECT ON combo_data.target',session_check=True)[0]==str(expected)
                result['measurements'].append({'query_id':qid,'operation':operation,'iteration':iteration,'warmup':iteration<2,'wall_ms':elapsed*1000})
                print('COMBO_SAMPLE',operation,iteration,round(elapsed*1000,3),flush=True)
        result['population_age_at_finish_seconds']=time.monotonic()-start;assert result['population_age_at_finish_seconds']<550
        a.query('SYSTEM FLUSH LOGS')
        logs=a.rows("SELECT query_id,toString(type) AS type,query_duration_ms,ProfileEvents['UserTimeMicroseconds']+ProfileEvents['SystemTimeMicroseconds'] AS cpu_us,ProfileEvents['EffectiveAccessRightsCalculations'] AS calculations,ProfileEvents['EffectiveAccessRightsCacheHits'] AS cache_hits FROM system.query_log WHERE startsWith(query_id,'"+f.identity+"_combo_') AND type!='QueryStart'")
        assert len(logs)==24 and all(row['type']=='QueryFinish' for row in logs)
        by_id={row['query_id']:row for row in logs}
        for sample in result['measurements']:
            sample['server']=by_id[sample['query_id']]
            if args.variant=='B':assert int(sample['server']['calculations'])==args.combinations,sample
        result['summaries']={}
        for operation in ('GRANT','REVOKE'):
            values=sorted(sample['wall_ms'] for sample in result['measurements'] if sample['operation']==operation and not sample['warmup'])
            result['summaries'][operation]={'samples':len(values),'p50_ms':statistics.median(values),'p95_ms':values[math.ceil(.95*len(values))-1],'max_ms':max(values)}
        result['status']='passed';print('COMBO_CASE_PASS',args.variant,args.combinations,json.dumps(result['summaries']),flush=True)
except BaseException as error:
    result.update(status='failed',error=repr(error));raise
finally:
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
