#!/usr/bin/env python3
"""Execute sequential A/B/B/A blocks after B has finished building."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import uuid

ROOT = Path(__file__).resolve().parent
DOCKER = os.environ.get("DOCKER", "/Applications/Docker.app/Contents/Resources/bin/docker")
IMAGE = "clickhouse/binary-builder@sha256:11d62ca44c2c4bb944000ce6740e0af8588672ef9d2a60af006aab954ba2f02f"


def checked(*args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)


def check_container_isolation(allowed_name, audit_path):
    # A single daemon snapshot avoids inspecting an already removed --rm container.
    snapshot = subprocess.check_output(
        [DOCKER, "ps", "--format", '{"name":{{json .Names}},"state":{{json .State}}}'], text=True)
    containers = [json.loads(line) for line in snapshot.splitlines()]
    unrelated = [item for item in containers if item["name"] != allowed_name]
    unexpected = [item["name"] for item in unrelated if item["state"] != "paused"]
    record = {"utc": datetime.now(timezone.utc).isoformat(),
              "paused_unrelated": sum(item["state"] == "paused" for item in unrelated),
              "running_unpaused_unrelated": unexpected,
              "snapshot_method": "single_docker_ps"}
    with audit_path.open("a") as output:
        output.write(json.dumps(record) + "\n")
    assert not unexpected, f"Unrelated containers active: {unexpected}"


def p95(values):
    return sorted(values)[math.ceil(len(values) * 0.95) - 1]


def summarize(results, output):
    groups = {}
    samples = []
    for run in results:
        assert run["status"] == "passed"
        key = (run["context_mode"], run["sessions"], run["variant"])
        for row in run["measurements"]:
            if row["warmup"]:
                continue
            record = dict(row, mode=key[0], sessions=key[1], variant=key[2], block=run["block"])
            groups.setdefault(key + (row["operation"],), []).append(record)
            samples.append(record)
    summaries = []
    for (mode, sessions, variant, operation), rows in sorted(groups.items()):
        client = [x["client_seconds"] * 1000 for x in rows]
        cpu = [(int(x["server"]["user_cpu_us"]) + int(x["server"]["system_cpu_us"])) / 1000 for x in rows]
        blocks = sorted({x["block"] for x in rows})
        summaries.append({
            "mode": mode, "sessions": sessions, "variant": variant, "operation": operation,
            "samples": len(rows), "client_median_ms": statistics.median(client),
            "client_p95_ms": p95(client), "client_min_ms": min(client), "client_max_ms": max(client),
            "cpu_median_ms": statistics.median(cpu),
            "server_median_ms": statistics.median(int(x["server"]["query_duration_ms"]) for x in rows),
            "query_memory_max_bytes": max(int(x["server"]["memory_usage"]) for x in rows),
            "calculations_range": [min(int(x["server"]["calculations"]) for x in rows), max(int(x["server"]["calculations"]) for x in rows)],
            "cache_hits_range": [min(int(x["server"]["cache_hits"]) for x in rows), max(int(x["server"]["cache_hits"]) for x in rows)],
            "block_client_medians_ms": {str(b): statistics.median(x["client_seconds"] * 1000 for x in rows if x["block"] == b) for b in blocks},
        })
    output.write_text(json.dumps({"status": "passed", "summaries": summaries, "samples": samples}, indent=2))
    return summaries


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples", type=int, default=10)
    parser.add_argument("--warmups", type=int, default=2)
    parser.add_argument("--pilot", action="store_true")
    args = parser.parse_args()
    assert (ROOT / "bin/clickhouse-A-runtime").is_file()
    assert (ROOT / "bin/clickhouse-B").is_file(), "B must be built before the matrix starts"
    assert (ROOT / "build/build_D.exit").read_text().strip() == "0"
    state = json.loads(subprocess.check_output([DOCKER, "inspect", "pr117270-build-d", "--format", "{{json .State}}"], text=True))
    assert not state["Running"], "Do not benchmark while compilation is running"
    run_id = uuid.uuid4().hex[:10]
    root = ROOT / "build" / ("matrix_" + run_id)
    root.mkdir()
    cases = [(mode, count) for mode in ("shared", "distinct") for count in (1, 10, 50)]
    variants = ("A", "B", "B", "A")
    if args.pilot:
        cases = [("distinct", 1), ("distinct", 50)]
        variants = ("A", "B")
    manifest = {
        "run_id": run_id, "started_utc": datetime.now(timezone.utc).isoformat(),
        "image": IMAGE, "order": variants, "cases": cases, "pilot": args.pilot,
        "samples_per_block_per_operation": args.samples, "warmups_per_block_per_operation": args.warmups,
        "container_limits": {"memory_gib": 6, "cpus": 4, "cpuset": "0-3", "network": "none"},
        "dataset_snapshot_date": "2026-09-18", "status": "running", "completed_runs": [],
        "isolation_check_interval_seconds": 5,
        "harness_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                           for name in ("run_case.py", "run_matrix.py")},
    }
    results = []
    manifest_path = root / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2))
    try:
        for mode, sessions in cases:
            for block, variant in enumerate(variants):
                key = f"{mode}_{sessions:02d}_{block}_{variant}"
                target = root / key
                target.mkdir()
                name = "pr117270-bench-" + run_id + "-" + key.lower()
                binary = "clickhouse-A-runtime" if variant == "A" else "clickhouse-B"
                command = [DOCKER, "run", "--rm", "--name", name,
                           "--platform", "linux/arm64", "--network", "none",
                           "--hostname", "pr117270-bench", "--add-host", "pr117270-bench:127.0.0.1",
                           "--memory", "6g", "--memory-swap", "6g", "--cpus", "4", "--cpuset-cpus", "0-3",
                           "--mount", f"type=bind,src={ROOT / 'bin'},dst=/inputs,readonly",
                           "--mount", f"type=bind,src={ROOT / 'run_case.py'},dst=/run_case.py,readonly",
                           "--mount", f"type=bind,src={target},dst=/out",
                           "--entrypoint", "python3", IMAGE,
                           "/run_case.py", "--binary", "/inputs/" + binary, "--variant", variant,
                           "--sessions", str(sessions), "--mode", mode, "--block", str(block),
                           "--samples", str(args.samples), "--warmups", str(args.warmups)]
                (target / "command.json").write_text(json.dumps(command, indent=2))
                print("RUN_START", key, flush=True)
                audit_path = root / "container_isolation.jsonl"
                check_container_isolation(name, audit_path)
                with (target / "test.log").open("w") as log:
                    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
                    try:
                        while True:
                            try:
                                code = process.wait(timeout=5)
                                break
                            except subprocess.TimeoutExpired:
                                check_container_isolation(name, audit_path)
                        assert code == 0, f"Benchmark container exited {code}"
                        check_container_isolation(name, audit_path)
                    except BaseException:
                        # Stop only this runner's disposable benchmark container.
                        subprocess.run([DOCKER, "stop", "--time", "5", name], stdout=log, stderr=subprocess.STDOUT)
                        process.wait()
                        raise
                result = json.loads((target / "result.json").read_text())
                assert result["status"] == "passed", result.get("error")
                assert result["harness_sha256"] == manifest["harness_sha256"]["run_case.py"]
                results.append(result)
                manifest["completed_runs"].append(str(target.relative_to(ROOT)))
                manifest_path.write_text(json.dumps(manifest, indent=2))
                print("RUN_PASS", key, flush=True)
        # Both binaries must see the exact same synthetic ACL fixture.
        assert len({r["dataset"]["fixture_sha256"] for r in results}) == 1
        summaries = summarize(results, root / "summary.json")
        manifest["status"] = "passed"
        print("MATRIX_PASS", root, "runs", len(results), "rows", len(summaries), flush=True)
    except Exception as error:
        manifest.update(status="failed", error=repr(error))
        raise
    finally:
        manifest["finished_utc"] = datetime.now(timezone.utc).isoformat()
        manifest_path.write_text(json.dumps(manifest, indent=2))
        (ROOT / "latest_matrix.json").write_text(json.dumps({"path": str(root), "status": manifest["status"], "pilot": args.pilot}, indent=2))


if __name__ == "__main__":
    main()
